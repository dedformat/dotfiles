// Approval Element for the Multi Approval Dialog
app.view.MultiApprovalElement = app.view.Base.extend({
    template: 'multi-approval-element',
    className: 'multi-approval-element collapsed',
    tagName: 'tr',
    attributes: {
        'data-toggle': 'collapse'
    },
    events: {
        'click .approval-deny': 'denyClicked',
        'click .approval-ok': 'okClicked',
        'click': 'handleClick'
    },
    initialize: function() {
        app.view.Base.prototype.initialize.apply(this, arguments);
        this._detailsView = null;
        this.listenTo(this.model, 'remove', this.remove);
    },
    postRender: function() {
        this.$('[data-toggle=tooltip]').tooltip({
            delay: { "show": 750, "hide": 0 }
        });
    },
    respondToRequest: function(response, cb) {
        var status = response ? SyncConstants.SYNC_REQUEST_APPROVED : SyncConstants.SYNC_REQUEST_REJECTED;
        var req = new app.model.RequestStatus;
        req.save({
            secret: this.model.get('folder'),
            fingerprint: this.model.get('user_identity').fingerprint,
            status: status
        }, {
            success: function() {
                console.log('request saved');
                cb && cb();
            }
        });
    },
    okClicked: function(e) {
        var _this = this;
        this.respondToRequest(true, function() {
            console.log('dismiss called');
            _this.dismiss();
        });
        e.stopPropagation();
    },
    denyClicked: function(e) {
        var _this = this;
        this.respondToRequest(false, function() {
            console.log('dismiss called');
            _this.dismiss()
        });
        e.stopPropagation();
    },
    handleClick: function(e) {
        if (!this._detailsView) {
            this.$el.removeClass('collapsed');
            this.$el.addClass('expanded');
            this._detailsView = new app.view.MultiApprovalDetails({ model: this.model });
            this.$el.after(this._detailsView.render().el);
            this._detailsView.show();
        } else {
            var _this = this;
            this.$el.removeClass('expanded');
            this.$el.addClass('collapsed');
            this._detailsView.hide(function() {
                _this._detailsView.remove();
                _this._detailsView = null;
            });
        }
        e.stopPropagation();
    },
    dismiss: function() {
        var collection = this.model.collection;
        collection.remove(this.model);
        collection.fetch();
    },
    remove: function() {
        if (this._detailsView) {
            this._detailsView.remove();
            this._detailsView = null;
        }
        app.view.Base.prototype.remove.apply(this, arguments);
    }
});


// Approval Element for the Multi Approval Dialog
app.view.MultiApprovalDetails = app.view.Base.extend({
    template: 'multi-approval-details',
    className: 'multi-approval-details',
    tagName: 'tr',
    events: {
    },
    initialize: function() {
        app.view.Base.prototype.initialize.apply(this, arguments);
        this.listenTo(this.model, 'remove', this.remove);
    },
    show: function(cb) {
        var container = this.$el.find('.approval-details-container');
        var autoHeight = container.css('height', 'auto').height();
        container.css('height', '0px');
        this.$el.removeClass('closed').addClass('expanded');
        container.animate({
            height: autoHeight + 'px'
        }, 300, function() {
            cb && cb();
        });
    },
    hide: function(cb) {
        var _this = this;
        this.$el.find('.approval-details-container').animate({
            height: '0px'
        }, 300, function() {
            _this.$el.removeClass('expanded').addClass('closed');
            cb && cb();
        });
    }
});


app.view.MultiApprovalDialog = app.view.BaseDialog.extend({
    template: 'multi-approval-dialog',
    id: 'multi-approval-dialog',
    events: {
        'hidden.bs.modal': 'remove'
    },
    initialize: function() {
        app.view.BaseDialog.prototype.initialize.apply(this, arguments);

        _.bindAll(this, 'renderModel');
        this.listenTo(this.collection, 'add remove', this.collectionChanged);

        this._views = [];
        this.options.count = this.options.secretfilter ? this.collection.where({'folder': this.options.secretfilter}).length: this.collection.length;
    },
    postRender: function() {
        this.collection.each(this.renderModel);
    },
    renderModel: function(model) {
        if (this.options.secretfilter && model.get('folder') !== this.options.secretfilter)
            return;

        var view = new app.view.MultiApprovalElement({ model: model });
        this.$el.find('tbody').append(view.render().el);
        this._views.push(view);
    },
    collectionChanged: function() {
        this.options.count = this.options.secretfilter ? this.collection.where({'folder': this.options.secretfilter}).length: this.collection.length;
        this.$el.find('#request-count').text(this.collection.length);
        this.$el.find('#request-text').text(' ' + app.utils.inflectNoun(this.collection.length, $.t('approvalRequest'), $.t('approvalRequests')));
        this.setEmptyMessage();
    },    
    setEmptyMessage: function() {
        if(this.collection.length) {
            this.$('.tableScrollContainer').removeClass('empty');
            return;
        }
        this.$('.tableScrollContainer').addClass('empty');
    },
    remove: function() {
        while(this._views.length) {
            this._views.pop().remove();
        }

        app.view.Base.prototype.remove.apply(this, arguments);
    }
});

