app.model.FolderPreferences = app.model.PropertyModel.extend({
	propertyName: 'folderpref',
	buildURL: function(method) {
		var url = app.model.PropertyModel.prototype.buildURL.apply(this, arguments);
		if(method == 'read') {
			url = url + '&secret=' + this.get('secret');
		}
		return url;
	}
});


app.view.FolderPreferences = app.view.BaseDialog.extend({
	template: 'folder-preferences',
	id: 'folder-pref-dialog',
	events: {
		'click #addhost': 'addHost',
		'click #useHostsLabel': 'toggleHosts',
		'click #updateSecretButton': 'openSecretDialog',
		'change input[type=checkbox]': 'savePref',
		'hidden.bs.modal': 'remove'
	},
	initialize: function() {
		_.bindAll(this, 'addHost', 'hostsList', 'savePref', 'initCopyButton');
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.options.pageTitle = $.t('preferences');
		this.folderPrefModel = new app.model.FolderPreferences({
			secret: this.model.get('secret')
		});

		this.options.browserInfo = app.browserInfo;

		_.extend(this.options, {
			prefs: this.folderPrefModel.attributes
		});

		this.listenTo(this.folderPrefModel, 'change', this.render);
		this.folderPrefModel.fetch();
	},
	postRender: function() {
		this.setMaxHeight();
		this.initCopyButton();
		this.hostsList();
	},
	openSecretDialog: function() {
		this.$el.modal('hide');
		app.updateSecretView.setModel(this.model);
		app.updateSecretView.render();
		app.updateSecretView.open();
	},
	initCopyButton: function() {
		if(!app.isDesktop) {
			var _this = this;
			this.$('.copy-btn').on('click', function() {
				var copyDialog = new app.view.CopyDialog({
					model: _this.model,
					text: $(this).attr('data-clipboard-target')
				});
				copyDialog.insert().open();
			});
			return;
		}

		var _this = this;
		this.$('.copy-btn').show().on('click', function() {
			btsync.copytoclipboard({text:$(this).attr('data-clipboard-target')});
			app.notify(
				$.t('secretCopyNotification'),
				'"' + _this.model.get('name') + '" - ' +
				$.t($(this).attr('data-secret-type')));
		});
	},
	addHost: function() {
		secret = this.model.get('secret');
		_this = this;
		utWebUI.addHost(secret, $("#address").val(), $("#port").val(), function() {
			_this.hostsList();
		});
		$('#address').val('');
		$('#port').val('');
	},
	toggleHosts: function() {
		if($('#usehosts').is(':checked'))
			return $('#predefinedHostsSection').show();
		$('#predefinedHostsSection').hide();
	},
	hostsList: function() {
		_this = this;

		utWebUI.getHosts(this.model.get('secret'), _.bind(function(data)
		{
			var hosts = data.value;
			var hostList = $("#hostlist");
			hostList.empty();

			for(var i = 0; i < hosts.length; ++i)
			{
				var v = new app.view.HostEntry({model: this.model, peer: hosts[i].peer, index: i});
				this.listenTo(v, 'removed', this.hostsList);
				hostList.append(v.render().el);
			}
		}, this));
	},
	savePref: function() {
		this.folderPrefModel.set({
			relay: this.$('#relay').prop('checked'),
			usetracker: this.$('#usetracker').prop('checked'),
			searchlan: this.$('#searchlan').prop('checked'),
			searchdht: this.$('#searchdht').prop('checked'),
			deletetotrash: this.$('#deletetotrash').prop('checked'),
			usehosts: this.$('#usehosts').prop('checked')
		},
		{
			silent: true
		});

		if(!this.model.get('iswritable'))
			this.folderPrefModel.set('override',
				this.$('#override').prop('checked'),
				{silent:true}
			);

		this.folderPrefModel.save();
	}
});


app.view.HostEntry = app.view.Base.extend({
	template: 'host-entry',
	tagName: 'li',
	events: {
		'click .close': 'removeHost'
	},
	removeHost: function() {
		s = this.model.get('secret');
		i = this.options.index;
		_this = this;
		utWebUI.removeHost(s, i, function(){
			_this.trigger('removed');
		});
	}
});


app.view.UpdateSecretDialog = app.view.BaseDialog.extend({
	template: 'update-secret-dialog',
	id: 'update-secret-dialog',
	events: {
		'click #generateNewSecretButton': 'newSecret',
		'click #updateSecretButton': 'updateSecret',
		'click #cancelButton': 'close',
		'show.bs.modal': 'showing'
	},
	initialize: function() {
		_.bindAll(this, 'setNewSecret');
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		this.options.pageTitle = $.t('updateSecret');
	},
	setModel: function(m) {
		this.model = m;
		this.$('.modal-header h2').html(this.callTemplate('partial-folder-path'));
	},
	showing: function() {
		this.$('input[name=newSecret]').val('').removeClass('warning');
	},
	open: function() {
		this.$el.modal('show');
	},
	close: function() {
		this.$el.modal('hide');
		var folderPrefDialog = new app.view.FolderPreferences({
			model: this.model
		});
		folderPrefDialog.insert().openScroll();
	},
	newSecret: function() {
		utWebUI.generateSecret(_.bind(function(d)
		{
			this.setNewSecret(d.value.secret);
		}, this));
	},
	updateSecret: function() {
		var s = this.$('input[name=newSecret]').val();
		var _this = this;
		if(!s) {
			this.$('input[name=newSecret]').addClass('warning');
			return;
		}
		this.setNewSecret(s, {
			error: function(e) {
				_this.$('input[name=newSecret]').addClass('warning');
				_this.$('.updateSecretErrorContainer').find('span:last-child').text($.t('updateSecretError' + e.error_code)).end().removeClass('invisible');
			}
		});
	},
	setNewSecret: function(s, opts) {
		this.model.setNewSecret(s, {
			success: _.bind(function() {
				app.updateSecretSuccessView.setModel(this.model);
				this.$el.modal('hide');
				app.updateSecretSuccessView.open();
				opts && opts.success && opts.success.apply(this, arguments);
			}, this),
			error: opts && opts.error
		});
	}
});

app.view.UpdateSecretSuccessDialog = app.view.BaseDialog.extend({
	template: 'update-secret-success-dialog',
	events: {
		'click #undoButton': 'undo',
		'click .copy-btn': 'copyClicked'
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		this.options.pageTitle = $.t('updateSecret');
	},
	setModel: function(m) {
		this.model = m;
		this.render();
		this.$('.modal-header h2').html(this.callTemplate('partial-folder-path'));
	},
	open: function() {
		this.$el.modal('show');
	},
	undo: function() {
		this.model.setNewSecret(this.model.get('oldSecret'), {
			success: _.bind(function() {
				this.$el.modal('hide');
				var folderPrefDialog = new app.view.FolderPreferences({
					model: this.model
				});
				folderPrefDialog.insert().openScroll();
			}, this)
		});
	},
	copyClicked: function() {
		btsync.copytoclipboard({text:this.$('input').val()});
		app.notify(
			$.t('secretCopyNotification'),
			'"' + this.model.get('name') + '"'
		);
	}
});


