app.view.IntegrationDialog = app.view.BaseDialog.extend({
    template: 'integration-dialog',
    id: 'integration-dialog',
    events: {
        'hidden.bs.modal': 'remove'
    },
    initialize: function() {
        app.view.BaseDialog.prototype.initialize.apply(this, arguments);
    }
});

