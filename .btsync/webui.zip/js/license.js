app.model.License = app.model.PropertyModel.extend({
	propertyName: 'licenseagreed'
});


app.view.License = app.view.BaseDialog.extend({
	template: 'license-dialog',
	id: 'license-dialog',
	events: {
		'click .accept': 'accept',
		'show.bs.modal': 'beforeShow',
		'change input[name=licenseAccept]': 'toggleAccept',
		'click a': 'handleExternalLink'
	},
	beforeShow: function() {
		// TODO: on linux, need to get credentials (action=cred) to check haspassword
		if(!this.model.get('passwordset') && !app.isDesktop) {
			this.$("#pass-username").val(app.utils.fixUnicode(this.options.username || ''));
			this.$('.introGraphic').hide();
		}
		else
			this.$('#userpassModule').hide();
	},
	toggleAccept: function() {
		this.$('.accept').prop('disabled', !this.$('input[name=licenseAccept]').is(':checked'));
	},
	accept: function() {
		// check matching passwords
		if(this.$('#pass-newpassword').val() != this.$('#pass-confirmpassword').val()) {
			this.$('#pass-confirmpassword').parent().addClass('has-error');
			this.$('#passNoMatchMessage').show();
			return false;
		}
		if(!this.$('input[name=licenseAccept]').is(':checked')) {
			this.$('input[name=licenseAccept]').closest('div').addClass('has-error');
			return false;
		}

		var licenseModel = new app.model.License;
		licenseModel.set('value', true);

		if(this.$('#userpassModule').is(':visible'))
			licenseModel.set({
				'username': this.$('#pass-username').val(),
				'newpwd': this.$('#pass-newpassword').val(),
				'oldpwd': ''
			});
		licenseModel.save(null, {
			success: _.bind(function(model, resp) {
				// check for error
				if(resp.value.error) {
					this.$('#credentialsError').html($.t('credentialsError' + resp.value.error));
					this.$('.alert').show();
					return;
				}

				this.close();

				this.options.successCallback.apply(this, arguments);
			}, this)
		});

	},
	open: function() {
		this.$el.modal({
			backdrop: 'static',
			keyboard: false
		});
	}
});