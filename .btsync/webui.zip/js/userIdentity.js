app.model.UserIdentity = app.model.PropertyModel.extend({
	propertyName: 'useridentity'
});


app.view.UserIdentity = app.view.BaseDialog.extend({
	template: 'user-identity',
	id: 'userIdentity',
	events: {
		'click .btn-primary': 'save',
		'click .btn-default': 'cancel',
		'hidden.bs.modal': 'remove'
	},
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.options.username = app.systemInfo.username;
		this.options.devicename = app.settingsModel.get('devicename');
	},
	postRender: function() {
		this.$('[data-toggle=tooltip]').tooltip();
	},
	validate: function() {
		if(this.$('#username').val() == '') {
			this.$('#username').parent().addClass('has-error');
			return false;
		}
		if(this.$('#devicename').val() == '') {
			this.$('#devicename').parent().addClass('has-error');
			return false;
		}
		return true;
	},
	save: function() {
		if (!this.validate()) return;

		var _this = this;

		if (!app.userIdentity)
		{
			app.userIdentity = new app.model.UserIdentity();
		}

		app.userIdentity.set({
			username: this.$('#username').val(),
			devicename: this.$('#devicename').val()
		});
		app.userIdentity.save(null, {
			success: function() {
				app.settingsModel.save({
					devicename: _this.$('#devicename').val()
				}, {
					success: function() {
						_this.close();
						_this.options.callback(_this.$('#username').val());
						app.userIdentity.fetch();
					}
				});
			}
		});
	},
	cancel: function() {
		this.close();
		this.options.callback(false);
	}
});
