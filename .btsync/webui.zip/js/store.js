/*
	Further abstraction of datastore in order to enable column
	sizes to save from jquery.resizableColumns and in case
	integration with custom datastore on desktop is necessary
*/
(function() {
	app.store = {};
	if(!window.btsync) {
		app.store.get = amplify.store;
		app.store.set = amplify.store;
		app.store.init = function(cb) {
			cb && cb();
		}
		return;
	}


	// when on desktop, grab localstorage and replicate in memory
	app.model.LocalStorage = app.model.PropertyModel.extend({
		propertyName: 'localstorage'
	});


	var localStorage = new app.model.LocalStorage;
	var thestore;

	app.store.get = function(key) {
		if(!thestore) {
			try {
				thestore = JSON.parse(localStorage.get('value') || '{}');
			} catch(e) {
				thestore = {};
			}
		}
		if(!key)
			return thestore;
		return thestore[key];
	};
	app.store.set = function(key, value) {
		thestore[key] = value;
		localStorage.set('value', JSON.stringify(thestore));
		localStorage.save();
	};
	app.store.init = function(cb) {
		localStorage.fetch({
			success: cb
		});
	};

})();