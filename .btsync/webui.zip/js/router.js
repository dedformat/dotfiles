app.Router = Backbone.Router.extend({
	routes: {
		'share(/:path)': 'shareRoute',
		'addlink(/:path)': 'addSyncLink',
		'*path': 'defaultRoute'
	},
	shareRoute: function(path){
		if(!path) return;

		// Get Model
		var folders = new app.col.Folders();
		folders.fetch({
			success: function() {
				var m = folders.get(path);

				if (m) {
					document.title = $.t('share') + " - " + m.get('name');
					// Open Share page without modal
					var shareModal = new app.view.SharingDialogContent({model: m});
					shareModal.once('close', function() {
						btsync.closewindow();
					});
					
					$('body').append(shareModal.render().el);
					$('body').css('overflow', 'hidden');
					return;
				}

				// must have been a problem adding folder
				btAlert($.t('problemAddingFolder'));
			}
		});
	},
	addSyncLink: function(path) {
		if (!path) return;

		if (!app.initialized) {
			$('body').empty();
			initMainPage();
		}

		var encodedLink = encodeURIComponent(path);

		utWebUI.request('action=parselink&link=' + encodedLink, function(r) {

			var options = {
				folderName: r.value.name,
				ex: r.value.expired,
				path: r.value.default_path,
				link: encodedLink,
				size: r.value.size
			};

			var connectView = new app.view.Connect(options);
			connectView.insert().open();
		});
		return;
	},
	defaultRoute: function() {
		if (window.btsync && btsync.parameter) {
			try {
				var params = JSON.parse(btsync.parameter);
			} catch(e) {
				initMainPage();
				return;
			}

			if (!params.route) {
				initMainPage();
				return;
			}

			var fullroute = params.route + (params.query ? '?' + params.query : '');

			app.router.navigate(fullroute, {trigger: true, replace: true});
			btsync.parameter = undefined;
		} else {
			initMainPage();
			return;
		}
	}
});
