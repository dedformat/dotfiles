app.view.PendingModal = app.view.BaseDialog.extend({
	template: 'pending-dialog',
	id: 'pending-dialog',
    events: {
        'hidden.bs.modal': 'remove'
    },
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
        this.options.pageTitle = $.t('accessRequest');
		this.options.identity = app.userIdentity.toJSON();
	}
});