app.view.PeerListDialog = app.view.BaseDialog.extend({
	template: 'peer-list-dialog',
	id: 'peer-list-dialog',
	events: {
		'hidden.bs.modal': 'remove'
	},
	initialize: function() {
		_.bindAll(this, 'renderDevice', 'setEmptyMessage');
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);

		this._deviceViews = [];
		this.collection = this.model.get('devices');
		this.options.pageTitle = $.t('peerList');
		this.listenTo(this.collection, 'add', this.renderDevice);
		this.listenTo(this.collection, 'add remove', this.setEmptyMessage);

	},
	postRender: function() {
		app.view.BaseDialog.prototype.postRender.apply(this, arguments);
		this.setEmptyMessage();
		this.collection.each(this.renderDevice);
	},
	setEmptyMessage: function() {
		if(this.collection.length) {
			this.$('.tableScrollContainer').removeClass('empty');
			return;
		}
		this.$('.tableScrollContainer').addClass('empty');
	},
	renderDevice: function(d) {
		var v = new app.view.Device({
			model:d,
			secret: this.model.get('secret')
		});
		this._deviceViews.push(v);
		this.$('#peers-table tbody').append(v.render().el);
	},
	remove: function() {
		// remove devices views
		while(this._deviceViews.length)
			this._deviceViews.pop().remove();

		app.view.BaseDialog.prototype.remove.apply(this, arguments);
	}
});

