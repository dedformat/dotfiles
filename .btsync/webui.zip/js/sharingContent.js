app.view.SharingDialogContent = app.view.Base.extend({
	template: 'sharing-content',
	id: 'sharing-content',
	events: {
		'click .backButton': 'hideQR',
		'click .emailOption': 'email',
		'click .qrOption': 'showQR',
		'click  #radio-readwrite, #radio-readonly' : 'readChanged',
		'click input[type=checkbox]': 'toggleCheckbox',
		'click input[type=text]': 'clickTextfield',
		'keyup input[type=text]': 'keyupTextfield',
		'click .qrInstructions a': 'handleExternalLink'
	},
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.options.pageTitle = $.t('share');
	},
	postRender: function() {
		// Show read-only tab is not in a modal
		if (!this.options.isModal) {
			this.$("a[href=#sharing-ro-secret-tab]").tab('show');
			$('html').addClass('standalone');
		}

		// init tooltips
		this.$('[data-toggle=tooltip]').tooltip();

		// Init Copy
		var _this = this;
		this.initCopyButton();

		this.validator = new app.FormValidator({
			onkeyup: true,
			elements: [
				{
					element: this.$('input[name=expireValue]'),
					rules: {
						'required number': {
							depends: function() {
								return _this.$('input[name=chk_expireOption]').is(':checked');
							}
						}
					},
					messages: {
						required: $.t('pleaseEnterTimeLimit')
					}
				},
				{
					element: this.$('input[name=limitValue]'),
					rules: {
						'required digits': {
							depends: function() {
								return _this.$('input[name=chk_limitOption]').is(':checked');
							}
						}
					},
					messages: {
						required: $.t('pleaseEnterMaxValue')
					}
				}
			],
			showError: function(message, element) {
				$(element).parent().find('.error-container').text(message).show();
				$(element).addClass('warning');
			},
			hideError: function(element) {
				$(element).parent().find('.error-container').hide();
				$(element).removeClass('warning');
			}
		});

		if(!$.support.transition) return;

		this.$('#advancedShareOptions input').on($.support.transition.end, this.stopEventPropagation);
	},
	initCopyButton: function() {
		if(!app.isDesktop) {
			var _this = this;
			this.$('.copyOption').on('click', function() {
				if(!_this.validateFields()) return;
				_this.saveShareOptions()
				utWebUI.validateUserIdentity(function(val) {
					if (!val) return;
					
					_this.getSyncLink('copy', function(link) {
						var copyDialog = new app.view.CopyDialog({
							model: _this.model,
							textType: 'link',
							text: link
						});
						copyDialog.insert().open();
					});
				});
			});
			return;
		}

		var _this = this;
		this.$('.copyOption').on('click', function() {
			if(!_this.validateFields()) return;
			_this.saveShareOptions();
			utWebUI.validateUserIdentity(function(val) {
				if(!val) return;

				_this.getSyncLink('copy', function(link) {
					btsync.copytoclipboard({text:link});
					app.notify(
						$.t('linkCopyNotification'),
						'"' + _this.model.get('name') + '" - ' +
						$.t(_this.getParams().readwrite ? 'readWrite' : 'readonly'));
					_this.trigger('close');
				});
			});
		});
	},
	validateFields: function() {
		return this.validator.validate();
	},
	saveShareOptions: function() {
		var currentShareOptions = {
			readwrite: this.$('#radio-readwrite').prop('checked'),
			expiration: this.$('input[name=chk_expireOption]').is(':checked') ? parseFloat(this.$('input[name=expireValue]').val()) || 0 : 0,
			usages: this.$('input[name=chk_limitOption]').is(':checked') ? parseInt(this.$('input[name=limitValue]').val()) || 0 : 0,
			approvals: this.$('#cb-approval').is(':checked')
		}

		this.model.set('shareOptions', currentShareOptions);
		var allShareOptions = app.store.get('shareOptions');
		allShareOptions[this.model.get('secret')] = currentShareOptions;
		app.store.set('shareOptions', allShareOptions);
	},
	getKey: function() {
		if(this.$('#radio-readwrite').prop('checked'))
			return this.model.get('secret');
		return this.model.get('readonlysecret');
	},
	getParams: function() {
		var obj = {
			secret: this.model.get('secret'),
			readwrite: this.$('#radio-readwrite').prop('checked'),
			timelimit: this.$('input[name=chk_expireOption]').is(':checked') ? parseFloat(this.$('input[name=expireValue]').val()) * 24 * 60 * 60 || 0 : 0,
			clicklimit: this.$('input[name=chk_limitOption]').is(':checked') ? parseInt(this.$('input[name=limitValue]').val()) || 0 : 0,
			askapproval: this.$('#cb-approval').is(':checked')
		};

		obj.timelimitDays = obj.timelimit / 24 / 60 / 60;
		obj.expirationDate = moment().add('seconds', obj.timelimit).format('LL');
		return obj;
	},
	showQR: function() {
		var key = this.getKey();
		try {
			this.$(".qrCode").empty().qrcode({
				width: 200,
				height: 200,
				text: "btsync://" + key + "?n=" + encodeURIComponent(this.model.get('name'))
			});
		} catch(e) {}
		this.$('.mainSharePane').hide();
		this.$('.qrPane').show();
	},
	hideQR: function() {
		this.$('.qrPane').hide();
		this.$('.mainSharePane').show();
	},
	readChanged: function(e) {
		this.saveShareOptions();

		if(!this.$('.qrPane').is(':visible')) 
			return;

		this.showQR();
	},
	email: function() {
		if(!this.validateFields()) return;

		this.saveShareOptions();
		var _this = this;
		utWebUI.validateUserIdentity(function(val) {
			if(!val) return;
			_this.getSyncLink('email', function(link) {
				var subject = _this.model.get('name');
				var body = _this.callTemplate('template-share-email', {
					helpURI: 'http://getsync.com/',
					inviteLink: link,
					params: _this.getParams(),
					folderName: _this.model.get('name'),
					username: val
				});

				var url = 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);

				if(app.isDesktop) {
					btsync.openurl({url: url});
					_this.trigger('close');
					return;
				}

				window.open(url);
				_this.trigger('close');
			});
		});
	},
	getSyncLink: function(type, cb) {
		var params = this.getParams();
		params.type = type;
		utWebUI.getSyncLink(params.secret, params, function(r) {
			var link = r && r.value || '';
			cb && cb(link);
		});
	},
	toggleCheckbox: function(e) {
		var isChecked = $(e.currentTarget).prop('checked');
		$(e.currentTarget).parent().find('input[type=text]').prop('disabled', !isChecked).focus();
		isChecked ? $(e.currentTarget).parent().find('.help-block').show() : $(e.currentTarget).parent().find('.help-block').hide()

		if(this.validateFields()) this.saveShareOptions();
	},
	clickTextfield: function(e) {
		e.preventDefault();
		if(this.validateFields()) this.saveShareOptions();
	},
	keyupTextfield: function(e) {
		if(this.validateFields()) {
			this.saveShareOptions();
		}
	},
	stopEventPropagation: function(e) {
		// This is necessary to prevent the webkittransitionend event from
		// bubbling up to the collapse element when you click collapse while
		// focus is in an input. CRAZY!!
		e.stopPropagation();
	}
});