app.model.FolderSettings = app.model.APIModel.extend({
	request: 'action=getfoldersettings',
	parse: function(resp) {
		return resp && resp.folders;
	}
});
