/**
 * Widget makes columns of a table resizable.
 */
$.widget("bt.resizableColumns", {
	_minColWidth: 50,

	/**
	 * initializing columns
	 */
	_create: function() {
			this._setDefaultWidths();
			this._initResizable();
	},

	_setDefaultWidths: function() {
		this.storePrefix = this.element.find('colgroup').attr('data-resizable-columns-id');
		var _this = this;
		this.element.find('colgroup col[data-resizable-column-id]').each(function() {
			var colIndex = $(this).index() + 1;
			var otherElement = _this.element.find('.table-body col:nth-child(' + colIndex + ')');

			var width = _this._getWidth($(this).attr('data-resizable-column-id')) || $(this).data('min-width') || this._minColWidth;
			$(this).add(otherElement).css('width', width + 'px');
		});
	},

	/**
	 * init jQuery UI sortable
	 */
	_initResizable: function() {

		var colElement, colWidth, originalSize, newColWidth;
		var table = this.element;
		var _this = this;

		// add resize handles
		this.element.find('th.ui-resizable').each(function() {
			$(this).append('<div class="resizeHelper ui-resizable-handle ui-resizable-e" />');

			// firefox doesn't support position: relative on th element, so must add a wrapper to apply that to
			if(/firefox/i.test(navigator.userAgent))
				$(this).wrapInner('<div class="thInnerDiv" />');

			$(this).resizable({
				// use existing DIV rather than creating new nodes
				handles: {
					"e": $(this).find('.resizeHelper')
				},

				// default min width in case there is no label
				minWidth: 50,

				// set min-width to label size
				create: function(event, ui) {
					var minWidth = $(this).find(".columnLabel").width();
					if (minWidth) {
						// FF cannot handle absolute resizable helper
						/*if ($.browser.mozilla) {
								minWidth += $(this).find(".ui-resizable-e").width();
						}*/
						minWidth += $(this).find(".ui-resizable-e").width();

						$(this).resizable("option", "minWidth", minWidth);
					}
				},

				// set correct COL element and original size
				start: function(event, ui) {
					var colIndex = ui.helper.index() + 1;
					colElement = table.find("colgroup > col:nth-child(" + colIndex + ")");
					colWidth = parseInt(colElement.get(0).style.width, 10); // faster than width
					originalSize = ui.size.width;
					_this._trigger('start');
				},

				// set COL width
				resize: function(event, ui) {
					var resizeDelta = ui.size.width - originalSize;

					newColWidth = colWidth + resizeDelta;
					colElement.width(newColWidth);

					// height must be set in order to prevent IE9 to set wrong height
					$(this).css("height", "auto");

					_this._trigger('resize', event, {
						resizeDelta: resizeDelta
					});
				},

				// save col width to store
				stop: function() {
					_this._setWidth(colElement.attr('data-resizable-column-id'), newColWidth);
				}
			});
		});
	},

	_getWidth: function(col) {
		var colwidths = app.store.get(this.storePrefix) || {};
		return colwidths[col];
	},

	_setWidth: function(col, width) {
		var colwidths = app.store.get(this.storePrefix) || {};
		colwidths[col] = width;
		app.store.set(this.storePrefix, colwidths);
	}
});