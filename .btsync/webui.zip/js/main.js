app.view.Main = app.view.Base.extend({
	template: 'main',
	id: 'main',
	events: {
		'click #add-folder-button': 'addFolderClicked',
		'click #history-button':  'historyButtonClicked',
		'click #enter-link-button': 'enterLinkClicked'
	},
	_path: null,
	initialize: function() {
		_.bindAll(this, 'addFolderCallback', 'handleKeyPress', 'openAODDialog');
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.settingsDropdown = new app.view.SettingsDropdown;
		$(document).on('keypress', this.handleKeyPress);

		// Uncomment this line when AOD functionality is ready
		// cheet('up up down down left right left right a o d', this.openAODDialog);
	},
	postRender: function() {

		this.$('#topButtons .btn-naked').tooltip();

		this.$('.notificationButtonContainer').append(new app.view.NotificationCenterIcon().render().el);

		// open footer links in new window
		this.$('.navbar-fixed-bottom a').attr('target', '_blank');
		this.$('#settings-button-group').append(this.settingsDropdown.render().el);
		this.$('#user-agent').text(navigator.userAgent);

		if(!(app.store.get('firstRunTips') || {}).addFolder && !app.config.linkOnboarding)
			_.defer(_.bind(function() {
				this.$('#add-folder-button').firstRunTooltip({
					title: this.callTemplate('template-first-run-add-folder'),
					placement: 'bottom'
				}, 'addFolder');
				app.folders.once('userFolderAdded', _.bind(function() {
					this.$('#add-folder-button').tooltip('destroy');
				}, this));
			}, this));
	},
	handleKeyPress: function(e) {
		if (e.which === 21 && e.ctrlKey) {
			var ua = this.$el.find('#user-agent');
			if (ua.hasClass('hidden')) {
				ua.removeClass('hidden');
			} else {
				ua.addClass('hidden');
			}
			e.stopPropagation();
		}
	},
	addFolderClicked: function() {
		// use native dialog if on desktop
		if(app.isDesktop) {
			this._path = btsync.showchoosefolderdialog();
			if (this._path) {
				utWebUI.addSyncFolder(
					this._path,
					null,
					this.addFolderCallback);
			}
		} else {
			app.addFolderView.show();
		}
	},
	openAODDialog: function() {
		app.store.set('aodFlag', true);
		if (!app.aodCollection) {
			app.aodCollection = new app.col.AODCollection();
		}

		var aodDialog = new app.view.AODListDialog({
			collection: app.aodCollection
		});
		aodDialog.insert().openScroll();
		// gotta refresh settings dropdown list to have the new item
		this.settingsDropdown.render();
	},
	enterLinkClicked: function() {
		var enterKeyDialog = new app.view.EnterKey({addFolderView: app.addFolderView});	// we need to pass a reference to addFolderView to EnterKey
		enterKeyDialog.insert().open();
	},
	historyButtonClicked: function() {
		// Lazy Load History Collection
		if (!app.historyCollection) {
			app.historyCollection = new app.col.HistoryCollection();
		}

		var historyDialog = new app.view.HistoryDialog({
			collection: app.historyCollection
		});
		historyDialog.insert().openScroll();
	},
	handleFolderForceable: function(data) {
		var message = $.t('foldererror' + data.value.error, { folderName: data.value.path });
		btconfirm(message, _.bind(function(success) {
			if (success) {
				utWebUI.addForceSyncFolder(data.value.path, data.value.secret, this.addFolderCallback);
			}
		}, this));
	},
	handleFolderUnrecoverable: function(data) {
			btalert($.t('foldererror' + data.value.error, { folderName: data.value.path }));
	},
	handleFolderSuccess: function(data) {
		app.view.Base.prototype.handleFolderSuccess.apply(this, arguments);
		app.folders.newFolderAdded = true;

		// try to open share dialog
		// fetch folders
		app.folders.fetch({
			success: function() {
				// try to find folder
				var folder = app.folders.find(function(m) {
					return m.get('secret') == data.value.secret;
				});
				if(!folder) return;

				var d = new app.view.EmptyDialog({model:folder});
				d.insert().openScroll();
			}
		})
	}
});


app.view.SettingsDropdown = app.view.Base.extend({
	template: 'settings-dropdown',
	className: 'dropdown',
	events: {
		'click #enter-key-button': 'enterKeyClicked',
		'click #settings-button': 'settingsButtonClicked',
		'click #aods-button': 'aodsButtonClicked',
		'click #pause-button': 'pauseButtonClicked',
		'click #help-button': 'handleExternalLink',
		'show.bs.dropdown': 'closeTooltip',
		'hidden.bs.dropdown': 'enableTooltip'
	},
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.options.paused = app.pausedModel;
		this.listenTo(this.options.paused, 'change:value', this.render);
	},
	render: function() {
		this.options.aodFlag = app.store.get('aodFlag');
		var result = app.view.Base.prototype.render.apply(this,arguments);
		return result;
	},
	postRender: function() {
		this.enableTooltip();
	},
	enableTooltip: function() {
		this.$('.btn-naked').tooltip({
			placement: 'bottom',
			delay: 500,
			title: $.t('options')
		});
	},
	closeTooltip: function() {
		this.$('.btn-naked').tooltip('destroy');
	},
	enterKeyClicked: function() {
		var enterKeyDialog = new app.view.EnterKey({addFolderView: app.addFolderView});	// we need to pass a reference to addFolderView to EnterKey
		enterKeyDialog.insert().open();
	},
	aodsButtonClicked: function() {
		if (!app.aodCollection) {
			app.aodCollection = new app.col.AODCollection();
		}

		var aodDialog = new app.view.AODListDialog({
			collection: app.aodCollection
		});
		aodDialog.insert().openScroll();
	},
	settingsButtonClicked: function() {
		var settingsDialog = new app.view.Settings;
		settingsDialog.insert().openScroll();
	},
	pauseButtonClicked: function() {
		if(this.options.paused.get('value'))
			this.options.paused.set({value: false});
		else
			this.options.paused.set({value: true});
		this.options.paused.save();
		this.render();
	}
});


app.model.Paused = app.model.PropertyModel.extend({
	propertyName: 'pause',
	initialize: function() {
		_.bindAll(this, 'stateChanged');
		app.model.PropertyModel.prototype.initialize.apply(this, arguments);
		// listen for state change events
		$(window).on('SYNC_CALLBACK_EVENT_PAUSE_CHANGED', this.stateChanged);
	},
	stateChanged: function(w, d) {
		this.set(d);
	}
});
