(function() {
	var DEFAULTS = {};
	app.FormValidator = function(opts) {

		// set options
		opts = _.extend({
			// defaults
			elements: [],
			showError: function(message, element) {
				console.log(message, element);
			},
			hideError: function(element) {
				console.log('hiding errors', element);
			},
			showErrors: function(allErrors) {},
			hideErrors: function() {},
			onfocusout: true,
			onkeyup: false,
			onclick: false,
			focusCleanup: true
		}, DEFAULTS, opts);

		/*
		These messages and methods taken from jQuery Validation Plugin
		http://jqueryvalidation.org/
		*/
		var defaultMessages =  {
			required: $.t('validateRequiredDefault'),
			email: $.t('validateEmailDefault'),
			url: $.t('validateUrlDefault'),
			date: $.t('validateDateDefault'),
			number: $.t('validateNumberDefault'),
			digits: $.t('validateDigitsDefault')
		};

		var methods = {
			required: function( value ) {
				return $.trim(value).length > 0;
			},

			// http://jqueryvalidation.org/email-method/
			email: function( value ) {
				// From http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#e-mail-state-%28type=email%29
				// Retrieved 2014-01-14
				// If you have a problem with this implementation, report a bug against the above spec
				// Or use custom methods to implement your own email validation
				return /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test(value);
			},

			// http://jqueryvalidation.org/url-method/
			url: function( value ) {
				// contributed by Scott Gonzalez: http://projects.scottsplayground.com/iri/
				return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
			},

			// http://jqueryvalidation.org/date-method/
			date: function( value ) {
				return !/Invalid|NaN/.test(new Date(value).toString());
			},

			// http://jqueryvalidation.org/number-method/
			number: function( value ) {
				return /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
			},

			// http://jqueryvalidation.org/digits-method/
			digits: function( value ) {
				return /^\d+$/.test(value);
			}
		};

		var errorsArr = [];

		var validateItem = function(item, showErrors) {
			var elem = item.element;
			var value = elem.val();
			var itemValid = true;
			item.boundFunction = item.boundFunction || _.bind(validateItem, this, item, showErrors);
			item.boundHideFunction = item.boundHideFunction || _.bind(opts.hideError, this, elem);
			item.rules = item.rules || {};

			// validate each rule
			_.each(item.rules, function(val, rule) {
				var doValidation = true;
				if(_.isObject(val)) {
					if(val.depends) {
						doValidation = val.depends(item);
					}
				}
				else {
					doValidation = val;
				}
				if(doValidation) {
					// split rules
					rule = rule.split(' ');
					_.each(rule, function(r) {
						var ruleValid = methods[r](value);
						if(!ruleValid) {
							// show message
							var message = item.messages && item.messages[r] || opts.messages && opts.messages[r] || defaultMessages[r];
							if(showErrors && itemValid) { // only show the first error
								errorsArr.push({
									element: elem,
									message: message
								});
								opts.showError(message, elem);
							}
							itemValid = false;
						}
					});
				}
			});


			// hide error if item is now valid
			if(itemValid)
				opts.hideError(elem);

			// remove events
			var eventList = [
				opts.onfocusout ? 'focusout' : '',
				opts.onkeyup ? 'keyup' : '',
				opts.onclick ? 'click' : ''
			].join(' ');
			$(elem).off(eventList, item.boundFunction);
			if(opts.focusCleanup)
				$(elem).off('focus', item.boundHideFunction);

			if(!itemValid) {
				// set to validate on events
				$(elem).on(eventList, item.boundFunction);
				if(opts.focusCleanup)
					$(elem).on('focus', item.boundHideFunction);
			}

			return itemValid;
		};


		/*************
		PUBLIC METHODS
		*************/

		// validate all elements
		this.validate = function(showErrors) {
			showErrors = _.isUndefined(showErrors) ? true : showErrors;

			var valid = true;
			errorsArr = [];
			// check each element in 'elements'
			for(var i=0; i<opts.elements.length; i++) {
				valid = validateItem(opts.elements[i], showErrors) && valid;
			}

			if(!valid)
				opts.showErrors(errorsArr);
			else
				opts.hideErrors();

			return valid;
		};

		// validate a single element
		this.validateElement = function(elem, showErrors) {
			showErrors = _.isUndefined(showErrors) ? true : showErrors;

			// get item from 'elements'
			var item = _.filter(opts.elements, function(e) {
				return e.element = elem;
			});
			if(!item.length) return true;
			item = item[0];

			return validateItem(item);
		};

		// set default options
		this.defaults = function(opts) {
			DEFAULTS = opts;
		}

	};

	var example = {
		elements: [
			{
				element: this.$('input[name=timelimit]'),
				rules: {
					required: {
						depends: function() {
							return Math.random() < .5;
						}
					}
				},
				messages: {
					required: 'Time limit is required'
				}
			}
		],
		messages: {
			required: 'time limit is still required'
		}
	}
})();


