app.view.AddFolder = app.view.BaseDialog.extend({
	template: 'add-folder-dialog',
	id: 'add-folder-dialog',
	events: {
		'show.bs.modal': 'modalShown',
		'hide.bs.modal': 'modalHidden',
		'click #add-ok': 'okClicked',
		'click #add-cancel': 'cancelClicked',
		'click .addFolder': 'addFolder'
	},

	_secret: null,
	_folderMode: false,
	_folderCallback: null,

	initialize: function() {
		_.bindAll(this, 'addFolderCallback');
		_.bindAll(this, 'folderAttributeCallback');
		app.view.Base.prototype.initialize.apply(this, arguments);
	},
	show: function(key) {
		if (key) {
			this._secret = key;
		}
		this.open();
	},
	showToGetFolder: function(callback) {
		// TODO: seed with path
		// TODO: create more defined flows for get folder and add folder flows

		this.open();
		this._folderCallback = callback;
		this._folderMode = true;
	},
	modalShown: function() {
		this.$('#add-directory')
			.val('')
			.attr('placeholder', (app.folderSettings.get('default') || $.t('path')));
		this.refreshFileTree();
		//Gotta check first time to see if can write to starting dir
		utWebUI.getFolderAttr(app.folderSettings.get('default'), this.folderAttributeCallback);

		this.$('#create-folder').styleTooltip({css:{'z-index':1050}});
	},
	modalHidden: function() {
		this._secret = null;
		this.$("#add-error").addClass("hide");
		this._folderMode = false;
		this.$('#create-folder').styleTooltip('destroy');
	},
	refreshFileTree: function() {
		this.$('#filetree').fileTree({
			root: app.folderSettings.get('default'),
			delimiter: app.DELIMITER,
			expandSpeed: 1000,
			collapseSpeed: 1000,
			multiFolder: false,
			expandSpeed: 10,
			collapseSpeed: 10,
			folderEvent: 'click',
			that: this,
			onClick: function(t) {
				utWebUI.getFolderAttr(t, this.that.folderAttributeCallback);
				$("#add-directory").val(t);
			}
		}, function(file) {
			alert(file);
		});
	},
	cancelClicked: function() {
		if (this._folderMode) {
			if (this._folderCallback) {
				this._folderCallback(false);
			}
		}
		this.close();
	},
    folderAttributeCallback: function(result) {
		if (result.write === true) {
			this.$('.addFolder').removeClass('disabled');
			this.$('#create-folder').styleTooltip('disable');
		} else {
			this.$('.addFolder').addClass('disabled');
			this.$('#create-folder').styleTooltip('enable');
		}
	},
	okClicked: function() {
		if (this._folderMode) {
			if (this._folderCallback) {
				this._folderCallback(this.$('#add-directory').val());
				this.close();
			}
			return false;
		}

		var _this = this;

		if (this._secret) {
			if (this._secret.indexOf("getsync") > 0) {      // if invitation link
				utWebUI.validateUserIdentity(function(val) {
					if (!val) return;

					var request = 'action=addlink&link=' + encodeURIComponent(_this._secret) + '&path=' + encodeURIComponent(_this.$("#add-directory").val());
					utWebUI.request(request, _this.addFolderCallback);
				});
			} else {
				utWebUI.addSyncFolder(
					_this.$("#add-directory").val(),
					_this._secret,
					_this.addFolderCallback
				);
			}
			return false;
		} else {
			// Generate Secret
			utWebUI.addSyncFolder(
				this.$("#add-directory").val(),
				null,
				this.addFolderCallback
			);
			return false;
		}
	},
	addFolder: function(ev) {
		if($(ev.target).hasClass('disabled')) { return; }
		// add folder where current selection is
		$activeItem = this.$('#filetree').find('.active');
		dirPath = $activeItem.attr('rel');
		$ul = $activeItem.closest('li').children('ul');
		if(!$ul.length) {
			dirPath = app.folderSettings.get('default');
			$ul = this.$('#filetree').children('ul');
		}

		// if isn't expanded, expand and then continue
		if(!$activeItem.closest('li').hasClass('expanded')) {
			$activeItem.closest('li').removeClass('collapsed').addClass('expanded');
			$ul.show();
		}

		input = new app.view.NewDirectory();
		$ul.prepend(input.render().el);
		input.$('input').focus();
		_this = this;
		this.listenTo(input, 'nameChosen', function(name) {
			if(!name) {
				$ul.children(':first-child').remove();
				return;
			}

			dirPath = dirPath + '/' + name;
			$ul.children(':first-child').remove();
			utWebUI.addDirectory(dirPath)
				.done(function(resp) {
					if(resp.error) {
						alert($.t('foldererror' + resp.error));
						return;
					}
					_this.$("#add-directory").val(dirPath);
					var name = app.utils.fixUnicode(resp.path);
					if(name[name.length-1] == '/')
						name = name.slice(0,-1);
					var dir = new app.view.Directory({
						dirPath: dirPath,
						name: name.split('/').slice(-1)[0],
						active: true
					});
					$ul.prepend(dir.render().el);
					_this.listenTo(dir, 'selected', function() {
						this.$("#add-directory").val(dirPath);
					});
				});
		});
	},
	handleFolderForceable: function(data) {
		var _this = this;
		var message = $.t('foldererror' + data.value.error, { folderName: this.$("#add-directory").val() });
		btconfirm(message, function(success) {
			if (success) {
				utWebUI.addForceSyncFolder(data.value.path, _this._secret, _.bind(_this.addFolderCallback, _this));
			}
		});
	},
	handleFolderUnrecoverable: function(data) {
		this.$("#add-error")
			.text($.t('foldererror' + data.value.error))
			.removeClass("hide");
	},
	handleFolderSuccess: function(data) {
		app.view.BaseDialog.prototype.handleFolderSuccess.apply(this, arguments);
		this.$el.modal('hide');
		this.$("#add-error").text("").addClass("hide");
	}
});

app.view.NewDirectory = app.view.Base.extend({
	template: 'newdirectory',
	tagName: 'li',
	className: 'directory collapsed',
	events: {
		'keydown input': 'keyPressed',
		'blur input': 'saveName'
	},
	keyPressed: function(e) {
		if(e.which == 13) return this.saveName();
		if(e.which == 27) {
			this.remove();
			e.stopPropagation();
			return false;
		}
	},
	saveName: function() {

		this.trigger('nameChosen', this.$('input').val());
	}
});

app.view.Directory = app.view.Base.extend({
	template: 'directory',
	tagName: 'li',
	className: 'directory collapsed',
	events: {
		'click a': 'selected'
	},
	selected: function() {
		this.trigger('selected');
	},
	postRender: function() {
		if(!this.options.active) return;
		$('ul.jqueryFileTree a.active').removeClass('active');
		this.$('a').addClass('active');
	}
});
