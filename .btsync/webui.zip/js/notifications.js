app.view.NotificationCenterIcon = app.view.Base.extend({
	template: 'notification-center-icon',
	className: 'notification-center-icon',
	tagName: 'span',
	events: {
		'click #notifications-button': 'notificationsClicked'
	},
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.listenTo(app.notificationCenter, 'countChanged', this.updateBadgeCount);
	},
	deferred_post_render: function() {
		app.notificationCenter.setDockElement(this.$('#notifications-button'));
	},
	notificationsClicked: function() {
		var notificationButton = this.$('#notifications-button');
		if (notificationButton.hasClass('active')) {
			app.notificationCenter.hide();
		} else {
			app.notificationCenter.show();
		}
		return false;
	},
	updateBadgeCount: function(count) {
		if (!count) {
			this.$('#notifications-button').attr('disabled','disabled');
			return this.$('.mybadge').hide();
		}

		this.$('#notifications-button').removeAttr('disabled');
		this.$('.mybadge').text(count).show();
	}
});

app.view.NotificationCenter = app.view.Popout.extend({
	template: 'notification-center',
	className: 'popout-parent hidden notificationCenter',
	events: {
	},
	initialize: function() {
		_.bindAll(this, 'renderGroup');
		app.view.Popout.prototype.initialize.apply(this, arguments);

		this.groups = [];

		this.count = 0;
	},
	postRender: function() {
		this.renderGroups();
	},
	addGroup: function(notificationGroup) {
		this.groups.push(notificationGroup);
		this.listenTo(notificationGroup.collection, 'add remove', this.recount);
		this.listenTo(notificationGroup.collection, 'add', this.show);
		this.recount();
		this.renderGroup(notificationGroup);
	},
	renderGroups: function() {
		_.each(this.groups, this.renderGroup);
	},
	renderGroup: function(g) {
		this.$('.groupContainer').append(g.render().el);
	},
	recount: function() {
		var count = 0;
		_.each(this.groups, function(g) {
			count += g.collection.length;
		});

		if(count == this.count) return;

		this.count = count;

		if(this.count == 0) {
			this.$('.emptyMessage').show();
			this.hide();
		} else {
			this.$('.emptyMessage').hide();
		}
		
		this.trigger('countChanged', this.count);
	}
});


app.view.Notification = app.view.Base.extend({
	template: 'notification',
	className: 'notification',
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);

		this.listenTo(this.model, 'remove', this.remove);
	},
	remove: function() {
		// any cleanup work here
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});

app.view.ApprovalNotification = app.view.Notification.extend({
	template: 'approval-notification',
	className: app.view.Notification.prototype.className + ' approvalNotification',
	events: {
		'click .approval-ok': 'okClicked',
		'click .approval-deny': 'denyClicked',
		'click': 'openDetails'
	},
	initialize: function() {
		_.bindAll(this, 'dismiss');
		app.view.Notification.prototype.initialize.apply(this, arguments);
	},
	okClicked: function() {
		var _this = this;
		this.respondToRequest(true, function() {
			_this.dismiss();
		});
		return false;
	},
	denyClicked: function() {
		var _this = this;
		this.respondToRequest(false, function() {
			_this.dismiss();
		});
		return false;
	},
	openDetails: function() {
		var approvalDialog = new app.view.ApprovalDialog({
			model: this.model
		});
		approvalDialog.insert().open();
		return false;
	},
	respondToRequest: function(response, cb) {
		var status = response ? SyncConstants.SYNC_REQUEST_APPROVED : SyncConstants.SYNC_REQUEST_REJECTED;
		var req = new app.model.RequestStatus;
		req.save({
			secret: this.model.get('folder'),
			fingerprint: this.model.get('user_identity').fingerprint,
			status: status
		}, {
			success: function() {
				console.log('success');
				cb && cb()
			}
		});
	},
	dismiss: function() {
		var collection = this.model.collection;
		collection.remove(this.model);
		collection.fetch();
	}
});

app.view.PendingTaskNotification = app.view.Notification.extend({
	template: 'pending-task-notification',
	className: app.view.Notification.prototype.className + ' pendingTaskNotification',
	events: {
		'click': 'doTask',
		'click .dismiss': 'dismiss'
	},
	doTask: function() {
		utWebUI.handleLinkRequest(this.model.toJSON(), true);
		this.dismiss();
		return false;
	},
	dismiss: function() {
		var collection = this.model.collection;
		collection.remove(this.model);
		return false;
	}
});

app.view.UpdateTaskNotification = app.view.Notification.extend({
	template: 'update-task-notification',
	className: app.view.Notification.prototype.className + ' updateTaskNotification',
	events: {
		'click a': 'linkClicked',
		'click .dismiss': 'dismiss'
	},
	linkClicked: function(e) {
		this.handleExternalLink(e);
	},
	dismiss: function() {
		var collection = this.model.collection;
		collection.remove(this.model);
		return false;
	}
});

app.view.NotificationGroup = app.view.Base.extend({
	template: 'notification-group',
	childView: app.view.ApprovalNotification,
	className: 'notificationGroup',
	initialize: function() {
		_.bindAll(this, 'renderNotification');
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.collection.notificationgroup = true;

		this.listenTo(this.collection, 'add remove', this.toggleVisible);
		this.listenTo(this.collection, 'add remove', this.updateHeaderText);

		this.listenTo(this.collection, 'add', this.renderNotification);
	},
	toggleVisible: function() {
		if(this.collection.length) {
			return this.$el.removeClass('hidden');
		}
		this.$el.addClass('hidden');
	},
	postRender: function() {
		this.toggleVisible();
		this.updateHeaderText();
		this.renderNotifications();
	},
	renderNotifications: function() {
		this.collection.each(this.renderNotification);
	},
	renderNotification: function(m) {
		var childview = (m.get('childView') || this.childView);
		var v = new childview({
			model: m
		});
		this.$('.notificationContainer').append(v.render().el);
	},
	updateHeaderText: function() {
		if(this.collection.length == 1)
			return this.$('h4').text($.t(this.options.singularTitleTextID));

		this.$('h4').text($.t(this.options.pluralTitleTextID, {count: this.collection.length}));
	}
});

app.view.ApprovalNotificationGroup = app.view.NotificationGroup.extend({
	childView: app.view.ApprovalNotification,
	initialize: function() {
		app.view.NotificationGroup.prototype.initialize.apply(this, arguments);
		this.options.singularTitleTextID = '1ApprovalRequest';
		this.options.pluralTitleTextID = 'nApprovalRequests';
	}
});

app.view.PendingTaskNotificationGroup = app.view.NotificationGroup.extend({
	childView: app.view.PendingTaskNotification,
	initialize: function() {
		app.view.NotificationGroup.prototype.initialize.apply(this, arguments);
		this.options.singularTitleTextID = '1PendingTask';
		this.options.pluralTitleTextID = 'nPendingTasks';
	}
});
