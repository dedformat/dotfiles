app.model.HistoryEntry = Backbone.Model.extend({
	defaults: {
		"id": null,
		"time": null,
		"msg": null
	}
});
