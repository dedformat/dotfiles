app.model.AOD = app.model.APIModel.extend({
	defaults: {
		"address": null,
		"aod": null,
		"name": null,
		"state": null,
		"peerid": '',
		"peerport": null,
		"port": null
	},
	parse: function(resp) {
		resp.id = resp.address + ':' + resp.peerport;
		return resp;
	},
	request: function() {
		return "action=claimaod&" + $.param(_.pick(this.toJSON(), 'address', 'name', 'peerport', 'port', 'username', 'password'));
	},
	claim: function(username, password) {
		this.save({
			username: username,
			password: password
		}, {
			success: function(resp) {
				console.log("claimaod-data", resp);
			}
		});
	}
});

app.col.AODCollection  = Backbone.Collection.extend({
	model: app.model.AOD,
	sync: function(method, model, opts) {
		if (method === "read") {
			utWebUI.request("action=aods", function(data) {
				if (opts.success) {
					opts.success(data.value);
				}
			});
		}
	},
	parse: function(resp) {
		_.each(resp, function(item) {
			item = app.model.AOD.prototype.parse.call(this, item);
		});
		return resp;
	}
});

app.view.AOD = app.view.Base.extend({
	template: 'aod-device',
	className: 'aod-device',
	tagName: 'tr',
	events: {
		'click .claimButton' : 'claimAOD'
	},
	initialize: function(opt) {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.listenTo(this.model, 'change', this.render);
		this.listenTo(this.model, 'remove', this.remove);
	},
	claimAOD: function(e) {

		var aodClaimDialog = new app.view.AODClaimDialog({
			model: this.model
		});

		aodClaimDialog.insert().openScroll();

		return false;
	},
	remove: function() {
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});

app.view.AODListDialog = app.view.BaseDialog.extend({
	template: 'aod-list-dialog',
	id: 'aod-list-dialog',
	events: {
		'hidden.bs.modal': 'remove',
		'click #manual-claim-callout a': 'openManualClaim',
		'click #manual-claim-hide-callout a': 'closeManualClaim',
		'click #manual-claim-form .btn': 'manuallyClaimAOD',
		'keyup #manual-claim-form input[type=text]': 'inputKeyUp'
	},
	model: null,
	_aodViews: [],
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		_.bindAll(this, 'setEmptyMessage', 'addMyAOD', 'addNetworkAOD', 'filterModel');

		this.collection.fetch();
		this.listenTo(this.collection, 'add', this.filterModel);
		this.listenTo(this.collection, 'add remove reset', this.setEmptyMessage);

		this.listenTo(this.collection, 'reset', this.filterCollection);

		this.myAODs = new app.col.AODCollection;
		this.networkAODs = new app.col.AODCollection;

		this.listenTo(this.myAODs, 'add', this.addMyAOD);
		this.listenTo(this.networkAODs, 'add', this.addNetworkAOD);

		this.filterCollection();

		var _this = this;
		this.refreshIntervalID = setInterval(function() {
			_this.collection.fetch();
		}, 3000);
	},
	postRender: function() {
		app.view.BaseDialog.prototype.postRender.apply(this, arguments);
		this.filterCollection();
		this.myAODs.each(this.addMyAOD);
		this.networkAODs.each(this.addNetworkAOD);
		this.setEmptyMessage();
	},
	filterCollection: function() {
		this.collection.each(this.filterModel);
	},
	filterModel: function(m) {
		this.stopListening(m, 'change:state', this.filterModel);
		this.listenTo(m, 'change:state', this.filterModel);

		if(m.get('state') == 3) {
			this.networkAODs.remove(m);
			return this.myAODs.add(m);
		}
		this.myAODs.remove(m);
		this.networkAODs.add(m);
	},
	setEmptyMessage: function() {
		if (this.myAODs.length)
			this.$('#paired-aods-container').removeClass('empty');
		else
			this.$('#paired-aods-container').addClass('empty');

		if (this.networkAODs.length)
			this.$('#discovered-aods-container').removeClass('empty');
		else
			this.$('#discovered-aods-container').addClass('empty');
	},
	addMyAOD: function(d) {
		var v = new app.view.AOD({
			model:d
		});
		this._aodViews.push(v);
		this.$('#paired-aods-table tbody').append(v.render().el);
	},
	addNetworkAOD: function(d) {
		var v = new app.view.AOD({
			model:d
		});
		this._aodViews.push(v);
		this.$('#discovered-aods-table tbody').append(v.render().el);
	},
	manuallyClaimAOD: function(ev) {
		var m = new app.model.AOD({
			name: this.$("#manual-claim-form input[name='name']").val(),
			address: this.$("#manual-claim-form input[name='address']").val(),
			port: this.$("#manual-claim-form input[name='port']").val(),
			peerport: this.$("#manual-claim-form input[name='peerport']").val(),
			username: this.$("#manual-claim-form input[name='username']").val(),
			password: this.$("#manual-claim-form input[name='password']").val()
		});
		m.claim();
		this.closeManualClaim();
	},
	openManualClaim: function() {

		var animationDuration = 400;
		var animationEasing = 'easeInOutCubic';

		this.$('.bodyStuff').css({
			'height': this.$('#aod-lists-container').outerHeight()
		});
		this.$('#manual-claim-form').show();

		this.$('.bodySwitcher').animate({
			top: this.$('#aod-lists-container').outerHeight() * -1
		}, animationDuration, animationEasing);

		this.$('.bodyStuff').animate({
			height: this.$('#manual-claim-form').outerHeight()
		}, animationDuration, animationEasing);



		this.$('#manual-claim-callout').animate({
			opacity: 0
		}, animationDuration, animationEasing, function() {
			$(this).hide();
		});

		this.$('#manual-claim-hide-callout').show().animate({
			opacity: 1
		}, animationDuration, animationEasing);
	},
	closeManualClaim: function() {

		var animationDuration = 400;
		var animationEasing = 'easeInOutCubic';

		this.$('.bodySwitcher').animate({
			top: 0
		}, animationDuration, animationEasing, _.bind(function() {
			this.$('#manual-claim-form').hide();
		}, this));

		this.$('.bodyStuff').animate({
			height: this.$('#aod-lists-container').outerHeight()
		}, animationDuration, animationEasing, _.bind(function() {
			this.$('.bodyStuff').css('height', '');
		}, this));



		this.$('#manual-claim-callout').show().animate({
			opacity: 1
		}, animationDuration, animationEasing);

		this.$('#manual-claim-hide-callout').animate({
			opacity: 0
		}, animationDuration, animationEasing, function() {
			$(this).hide();
		});
	},
	inputKeyUp: function() {

		if(this.$("input[type=text]").filter(function(i, o) {
			return !$(o).val();
		}).length)
			return this.$('input[type=button]').prop('disabled', true);
		this.$('input[type=button]').prop('disabled', false);
	},
	remove: function() {
		clearInterval(this.refreshIntervalID);
		while(this._aodViews.length) {
			this._aodViews.pop().remove();
		}
		app.view.BaseDialog.prototype.remove.apply(this, arguments);
	}
});

app.view.AODClaimDialog = app.view.BaseDialog.extend({
	template: 'aod-claim-dialog',
	id: 'aod-claim-dialog',
	events: {
		'hidden.bs.modal': 'remove',
		'keyup :input': 'inputKeyUp',
		'click .btn.accept': 'submitClaim',
		'click .btn.cancel': 'close'
	},
	model: null,
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		_.bindAll(this, 'submitClaim', 'inputKeyUp');
	},
	inputKeyUp: function(ev) {
		this.validateInputs();
	},
	validateInputs: function() {
		if (this.model.get('state') === 0 && !this.$('#pass-confirmpassword').val()) {
			this.$('.btn.accept').prop('disabled', true);
		} else if (!this.$('#pass-newpassword').val() || !this.$('#pass-username').val()) {
			this.$('.btn.accept').prop('disabled', true);
		} else {
			this.$('.btn.accept').prop('disabled', false);
		}
	},
	submitClaim: function() {
		var username = this.$('#pass-username').val(),
		    password = this.$('#pass-newpassword').val();
		if (this.model.get('state') === 0 && (this.$('#pass-newpassword').val() != this.$('#pass-confirmpassword').val())) {
			$(this.$('#pass-confirmpassword')).parent().addClass('has-error');
			return;
		}
		this.model.claim(username, password);
		this.close();
	}
});

