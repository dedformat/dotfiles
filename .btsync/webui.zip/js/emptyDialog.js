app.view.EmptyDialog = app.view.BaseDialog.extend({
	template: 'empty-dialog',
	id: 'empty-dialog',
	events: {
		'show.bs.modal': 'showSubtab',
		'hidden.bs.modal': 'remove'
	},
	postRender: function() {
		// Render Contents
		app.view.BaseDialog.prototype.postRender.apply(this, arguments);
		this._contentView = new app.view.SharingDialogContent({
			model: this.model, 
			isModal: true
		});
		var _this = this;
		this.listenTo(this._contentView, 'close', function() {
			_this.close();
		});
		this.$el.find('#modal-content-container').append(this._contentView.render().el);
	},
	showSubtab: function() {
		// select read-only tab
		this.$("a[href=#sharing-ro-secret-tab]").tab('show');
	},
	remove: function() {
		this._contentView.remove();
		app.view.BaseDialog.prototype.remove.call(this);
	}
});