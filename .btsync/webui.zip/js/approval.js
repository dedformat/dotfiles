// Approval Model
app.model.Approval = Backbone.Model.extend({
	defaults: {
		"status": null,
		"readwrite": null,
		"approved": null,
		"folder": null,
		"user_identity": null
	},
	parse: function(r) {
		var folder = app.folders.get(r.folder);
		if(folder)
			r.folderName = folder.get('name');
		else
			r.folderName = 'unknown';
		return r;
	}
});

app.model.RequestStatus = app.model.PropertyModel.extend({
	propertyName: 'requeststatus'
});

// Approval Collection
app.col.Approvals = Backbone.Collection.extend({
	model: app.model.Approval,
	parse: function(models) {
		if(!_.isArray(models))
			return this.parseModel(models);
		return _.each(models, this.parseModel);
	},
	parseModel: function(m) {
		m.id = m.folder + m.user_identity.fingerprint;
		return m;
	},
	sync: function(method, model, opts) {
		switch(method) {
			case "create":
				break;
			case "read":
				utWebUI.request("action=getpendingrequests", function(data) {
					if (opts.success) {
						opts.success(data.value);
					}
				});
				break;
			case "update":
				break;
			case "delete":
				break;
		}
	}
});
