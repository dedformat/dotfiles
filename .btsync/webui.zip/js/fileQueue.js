// File Queue Model
app.model.FileQueue = app.model.APIModel.extend({
	request: function() {
		return 'action=queue&secret=' + this.options.secret + '&peer=' + this.options.peer;
	},
	initialize: function(opt) {
		this.options = opt;

		if (!this.options.secret || !this.options.peer) {
			throw new Error('The folder secret and peer id are required to retrieve the file queue');
		}

		this.on('change:files', this.parseFiles);
		this.parseFiles();
	},
	parse: function(resp) {
		return resp && resp.value;
	},
	parseFiles: function() {
		var col = this.get('filesCollection')
		if(!col) {
			col = new app.col.Files();
			this.set('filesCollection', col);
		}
		var f = this.get('files');
		col.set(f);

	}
});


app.model.FileQueueFile = Backbone.Model.extend({
	idAttribute: 'file'
});

app.col.Files = Backbone.Collection.extend({
	model: app.model.FileQueueFile
});


// File Queue File View
app.view.FileQueueFile = app.view.Base.extend({
	template: 'file-queue-file',
	tagName: 'tr',
	className: 'file-queue-file',
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		var tokens = this.model.get('file').split(app.DELIMITER);
		this.options.filename = tokens[tokens.length - 1];
		this.listenTo(this.model, 'remove', this.remove);
	}
});


// File Queue View
app.view.FileQueue = app.view.Base.extend({
	template: 'file-queue',
	tagName: 'tr',
	className: 'file-queue-row closed',
	limit: 50,
	initialize: function() {
		_.bindAll(this, 'onModelSuccess', 'renderFile');
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.model = new app.model.FileQueue(this.options);
		this.model.fetch({
			success: this.onModelSuccess
		});
		this.collection = this.model.get('filesCollection');
		this.listenTo(this.collection, 'add', this.renderFile);
		this.listenTo(this.collection, 'remove', this.renderOneMore);

		this.numRenderedViews = 0;

		var _this = this;
		this.timeout = setInterval(function() {
			_this.model.fetch();
		}, 2000);
	},
	onModelSuccess: function() {
		this.trigger('loaded', this.model.get('totalfiles'));
	},
	renderFile: function(f) {
		if(this.numRenderedViews >= this.limit) return;
		var container = this.$el.find('tbody');
		var fileQueueFileView = new app.view.FileQueueFile({
			model: f
		});
		this.numRenderedViews++;
		var _this = this;
		this.listenToOnce(fileQueueFileView, 'remove', function() {
			_this.numRenderedViews--;
		});
		container.append(fileQueueFileView.render().el);
		this.recount();
	},
	renderOneMore: function() {
		this.recount();
		if(this.numRenderedViews >= this.limit) return;
		if(!this.collection.at(this.numRenderedViews)) return;

		// render the next file in the collection,
		// assuming the views rendered so far are the first n in the collection
		this.renderFile(this.collection.at(this.numRenderedViews));
	},
	recount: function() {
		this.options.hiddencount = this.model.get('totalfiles') - this.limit;
		if(this.options.hiddencount < 1) {
			this.$('tfoot').hide();
			return;
		}
		this.$('tfoot').html(this.callTemplate('partial-file-message')).show();
	},
	show: function() {
		var container = this.$el.find('.file-queue-container');
		var autoHeight = container.css('height', 'auto').height();
		container.css('height', '0px');
		this.$el.removeClass('closed').addClass('expanded');
		container.animate({
			height: autoHeight + 'px'
		}, 300, function() {
			container.css('height', 'auto');
		});
	},
	hide: function(cb) {
		var _this = this;
		this.$('.file-queue-container').animate({
			height: '0px'
		}, 300, function() {
			_this.$el.removeClass('expanded').addClass('closed');
			cb && cb();
		});
	},
	remove: function() {
		clearInterval(this.timeout);
		this.numRenderedViews = 0;
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});

