app.view.CopyDialog = app.view.BaseDialog.extend({
	template: 'copy-dialog',
	id: 'copy-dialog',
	events: {
		'shown.bs.modal': 'selectText',
		'show.bs.modal': 'checkVisibleDialogs',
		'hidden.bs.modal': 'remove'
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		this.options = _.extend({
			textType: 'key'
		}, this.options);
		this.options.browserInfo = app.browserInfo;
	},
	selectText: function() {
		this.$('input,textarea').select();
	},
	checkVisibleDialogs: function() {
		if($('.modal:visible').length) {
			var _this = this;
			var visibleModal = $('.modal:visible');
			visibleModal.hide();
			this.$el.on('hidden.bs.modal', function() {
				visibleModal.show();
			});
		}
	}
});