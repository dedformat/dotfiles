app.model.Settings = app.model.PropertyModel.extend({
	propertyName: 'settings'
});
app.model.Language = app.model.PropertyModel.extend({
	propertyName: 'userlang'
});
app.model.Username = app.model.PropertyModel.extend({
	propertyName: 'credentials',
	parse: function(r) {
		return _.pick(r.value, ['username']);
	}
});
app.model.ProxySettings = app.model.PropertyModel.extend({
	propertyName: 'proxysettings',
	parse: function(r) {
		r = app.model.PropertyModel.prototype.parse.apply(this, arguments);
		return _.omit(r, ['status']);
	}
});


app.view.Settings = app.view.BaseDialog.extend({
	template: 'settings-dialog',
	id: 'settings-dialog',
	events: {
		'hidden.bs.modal': 'remove',
		'click input[name=chk_useProxy]': 'toggleProxySettings',
		'click input[name=chk_proxyAuth]': 'toggleProxySettings',
		'click #checkForUpdate': 'checkForUpdate',
		'change #sync-settings-general-tab input': 'setSettings',
		'change #sync-settings-advanced-tab input' : 'setValidatedSettings',
		'click #sync-settings-username-tab button': 'saveUsername',
		'click #deviceNameView a': 'editDeviceName',
		'blur #devicename': 'saveDeviceName',
		'keypress #devicename': 'devicenameKeypress',
		'click #showSuperAdvanced': 'showSuperAdvanced',
		'click .form-inline input[type=text]': 'clickTextfield',
		'change .form-inline input[type=checkbox]': 'toggleSettingDisabled'
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		_.bindAll(this, 'backupShown', 'languageChanged');
		this.$('a[href=#backup-tab]').on('shown.bs.tab', this.backupShown);

		this.languageModel = new app.model.Language;
		this.usernameModel = new app.model.Username;
		this.proxyModel = new app.model.ProxySettings;
		this.useridentityModel = app.userIdentity;
		this.columnsModel = new Backbone.Model(app.store.get('columns'));
		this.listenTo(this.columnsModel, 'change', function() {
			app.store.set('columns', this.columnsModel.toJSON());
			$(window).trigger('columnsChanged');
		});

		_.extend(this.options, {
			settings: app.settingsModel.attributes,
			language: this.languageModel.attributes,
			username: this.usernameModel.attributes,
			proxy: this.proxyModel.attributes,
			useridentity: this.useridentityModel.attributes,
			version: app.version,
			columns: this.columnsModel.toJSON()
		});

		// re-render settings after all models are fetched
		$.when(
			app.settingsModel.fetch(),
			this.languageModel.fetch(),
			this.usernameModel.fetch(),
			this.proxyModel.fetch()
		).always(_.bind(function() {
			_.defer(this.render);
			this.listenTo(this.proxyModel, 'change', this.toggleProxySaveMessage);
		}, this));
	},
	hide: function() {
		this.$el.modal('hide');
		this.stopListening(app.folders,'add remove change', this.generateBackup);
	},
	postRender: function() {
		this.$('#languagedrop').off('change');
		this.$('#languagedrop').selectpicker();
		this.$('#languagedrop').selectpicker('val', this.languageModel.get('value'));
		this.$('#languagedrop').on('change', this.languageChanged);

		this.$("#sync-settings-username-tab .alert").hide();
		this.$('[data-toggle=collapse]').addClass('collapsed');

		this.setMaxHeight();

		var _this = this;
		this.validator = new app.FormValidator({
			onkeyup: true,
			elements: [
				{
					element: this.$('#dlrate'),
					rules: {
						'required number': {
							depends: function() {
								return _this.$('#chk_dlrate').is(':checked');
							}
						}
					}
				},
				{
					element: this.$('#ulrate'),
					rules: {
						'required number': {
							depends: function() {
								return _this.$('#chk_ulrate').is(':checked');
							}
						}
					}
				},
				{
					element: this.$('#listeningport'),
					rules: {
						'required number': {
							depends: function() {
								return _this.$('#chk_listeningport').is(':checked');
							}
						}
					}
				}
			],
			showError: function(message, element) {
				$(element).parent().find('.error-container').text(message).show();
				$(element).addClass('warning');
			},
			hideError: function(element) {
				$(element).parent().find('.error-container').hide();
				$(element).removeClass('warning');
			}
		});
		this.proxyValidator = new app.FormValidator({
			onkeyup: true,
			elements: [
				{
					element: this.$('#proxyAddress'),
					rules: {
						'required': {
							depends: function() {
								return _this.$('input[name=chk_useProxy]').is(':checked')
							}
						}
					},
					messages: {
						required: $.t('proxyAddressRequiredMessage')
					}
				},
				{
					element: this.$('#proxyPort'),
					rules: {
						'required digits': {
							depends: function() {
								return _this.$('input[name=chk_useProxy]').is(':checked')
							}
						}
					},
					messages: {
						required: $.t('proxyPortRequiredMessage'),
						digits: $.t('proxyPortDigitsMessage')
					}
				}
			],
			showError: function(message, element) {
				$(element).addClass('warning');
			},
			showErrors: _.bind(function(allErrors) {
				this.$('#proxyErrorContainer').text(_.pluck(allErrors, 'message').join(', ')).show();
			}, this),
			hideError: function(element) {
				$(element).removeClass('warning');
			},
			hideErrors: _.bind(function(element) {
				this.$('#proxyErrorContainer').hide();
			}, this)
		});
	},
	validateFields: function() {
		return this.validator.validate() && this.proxyValidator.validate();
	},
	reRender: function() {
		var template = this.callTemplate("template-" + this.template);
		var generalTab = template.find('#sync-settings-general-tab');
		var advancedTab = template.find('#sync-settings-advanced-tab');
		var usernameTab = template.find('#sync-settings-username-tab');
		this.$el.find('.tab-content').empty().append(generalTab).append(advancedTab).append(usernameTab);
	},
	toggleProxySettings: function(e) {
		if(this.$('input[name=chk_useProxy]').is(':checked')) {
			this.$('#proxySettings').show();
			if($(e.currentTarget).closest('input[name=chk_useProxy]').length)
				this.$('#proxyAddress').focus();
		}
		else
			this.$('#proxySettings').hide();

		if(this.$('input[name=chk_proxyAuth]').is(':checked'))
			this.$('#proxyAuthSettings').show();
		else
			this.$('#proxyAuthSettings').hide();
	},
	toggleProxySaveMessage: function() {
		this.$('#proxySaveMessage').show();
	},
	checkForUpdate: function() {
		utWebUI.checkForUpdate(function(r) {
		});
		return false;
	},
	editDeviceName: function() {
		this.$('#deviceNameView').hide();
		this.$('#deviceNameEdit').show().find('#devicename').focus();
	},
	saveDeviceName: function(e) {
		app.settingsModel.save({
			devicename: this.$('#devicename').val()
		});
		this.$('#deviceNameEdit').hide();
		this.$('#deviceNameView')
			.find('#devicenameLabel')
			.text(this.$('#devicename').val())
		.end().show();
		e.stopPropagation();
	},
	languageChanged: function() {
		this.$('#languageSaveMessage').css('visibility','visible');
		this.setSettings();
	},
	devicenameKeypress: function(e) {
		if(e.which != 13) return;
		this.saveDeviceName(e);
	},
	generateBackup: function() {
		var keys = app.folders.map(function(m) {
			return {
				key: m.get('secret'),
				location: m.get('name')
			};
		});
		this.$('#backup-tab textarea').val(JSON.stringify(keys));
		try {
			this.$('#backup-tab textarea').select();
		} catch(e) {}
	},
	backupShown: function() {
		this.$('#backup-tab textarea').select().focus();
	},
	showSuperAdvanced: function() {
		btsync.showadvsett();
	},
	setValidatedSettings: function(e) {
		if(!this.validateFields()) return;
		this.setSettings(e);
	},
	setSettings: function(e) {
		// defer this code to increase UI responsiveness
		_.defer(_.bind(function() {

			if (e && e.target.id === "devicename") return;

			app.settingsModel.save({
				listeningport: this.$('#chk_listeningport').prop('checked') ? this.$('#listeningport').val() : 0,
				portmapping: this.$('#portmapping').prop('checked'),
				dlrate: this.$('#chk_dlrate').prop('checked') ? this.$('#dlrate').val() : 0,
				ulrate: this.$('#chk_ulrate').prop('checked') ? this.$('#ulrate').val() : 0,
				check_update: this.$('input[name=chk_checkForUpdates]').prop('checked'),
				autostart: this.$('input[name=chk_startAutomatically]').prop('checked'),
				show_notifications: this.$('input[name=chk_showNotifications]').prop('checked'),
				show_copy_key: this.$('input[name=chk_showCopy]').prop('checked'),
				debug_logging: this.$('#debuglogging').prop('checked')
			});

			this.languageModel.save({
				value: $('#languagedrop').selectpicker('val')
			});

			this.proxyModel.save({
				type: this.$('input[name=chk_useProxy]').is(':checked') ? parseInt(this.$('#proxyType option:selected').val()) : 0,
				addr: this.$('#proxyAddress').val(),
				port: parseInt(this.$('#proxyPort').val()),
				need_auth: this.$('input[name=chk_proxyAuth]').prop('checked'),
				username: this.$('#proxyAuthUsername').val(),
				password: this.$('#proxyAuthPassword').val(),
				proxy_resolve_hostnames: this.$('input[name=chk_proxyHostname]').prop('checked')
			});

			this.columnsModel.set({
				status: this.$('input[name=chk_col_status]').prop('checked'),
				receivingSpeed: this.$('input[name=chk_col_receivingSpeed]').prop('checked'),
				sendingSpeed: this.$('input[name=chk_col_sendingSpeed]').prop('checked'),
				progress: this.$('input[name=chk_col_progress]').prop('checked'),
				path: this.$('input[name=chk_col_path]').prop('checked'),
				size: this.$('input[name=chk_col_size]').prop('checked'),
				date_added: this.$('input[name=chk_col_dateAdded]').prop('checked'),
				last_modified: this.$('input[name=chk_col_dateModified]').prop('checked'),
				peers: this.$('input[name=chk_col_peers]').prop('checked')
			});

		}, this));
	},
	saveUsername: function() {
		var showError = _.bind(function(code) {
			this.$('#credentialsError').html($.t('credentialsError' + code));
			this.$('#sync-settings-username-tab .alert').show();
		}, this);
		this.usernameModel.save({
			username: this.$('#username').val(),
			oldpwd: this.$('#oldpassword').val(),
			newpwd: this.$('#newpassword').val()
		}, {
			success: _.bind(function(model, resp) {
				if(resp.value.error)
					return showError(resp.value.error);

				this.$('#sync-settings-username-tab .alert').hide();

				this.$('.saveConfirmation').css('display', 'inline-block');
				setTimeout(_.bind(function() {
					this.$('.saveConfirmation').fadeOut(500);
				}, this), 3000);

				// clear fields
				this.$('#oldpassword').val('');
				this.$('#newpassword').val('');
			}, this)
		});

	},
	clickTextfield: function(e) {
		e.preventDefault();
	},
	toggleSettingDisabled: function(e) {
		$(e.currentTarget).parent().find('input[type=text]')
		.prop('disabled', !$(e.currentTarget).prop('checked'))
		.focus();
	}
});
