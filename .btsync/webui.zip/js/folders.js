app.model.Folder = Backbone.Model.extend({
	idAttribute: 'secret',
	initialize: function() {
		this.on('change:peers', this.setupDevices);
		this.on('change', this.setStatusType);
		this.on('change:statusType', this.clearOutOfSyncTimer);
		this.setupDevices();
	},
	setupDevices: function() {
		var devices = this.get('devices')
		if(!devices) {
			devices = new app.col.Devices();
			this.set('devices', devices);
		}
		devices.set(this.get('peers'), {parse: true});

		var numConnectedPeers = 0,
				lastSentTime = 0,
				lastReceivedTime = 0,
				updiff = 0,
				downdiff = 0,
				connectedUpDiff = 0,
				connectedDownDiff = 0,
				syncedPeers = 0;

		devices.each(function(d) {
			if(d.get('isonline') == 1) {
				numConnectedPeers++;
				connectedUpDiff += d.get('updiff');
				connectedDownDiff += d.get('downdiff');
			}

			lastSentTime = Math.max(lastSentTime, d.get('lastsenttime'));
			lastReceivedTime = Math.max(lastReceivedTime, d.get('lastreceivedtime'));

			var peerUpdiff = d.get('updiff');
			var peerDowndiff = d.get('downdiff');
			updiff = updiff + peerUpdiff;
			downdiff = downdiff + peerDowndiff;

			if(!peerUpdiff && !peerDowndiff)
				syncedPeers++;
		});

		this.set({
			numConnectedPeers: numConnectedPeers,
			waitingToSend: updiff > 0,
			waitingToReceive: downdiff > 0,
			lastSentTime: lastSentTime,
			lastReceivedTime: lastReceivedTime,
			updiff: updiff,
			downdiff: downdiff,
			connectedDownDiff: connectedDownDiff,
			connectedUpDiff: connectedUpDiff,
			syncedPeers: syncedPeers
		});

		this.set('numPeers', devices.length);
	},
	parse: function(m) {
		m.type = m.iswritable ? 0 : 1;
		m.name = app.utils.fixUnicode(m.name);
		m.path = app.utils.fixUnicode(m.path);
		m.readonlysecret = m.readonlysecret || m.secret;
		m.down_eta = m.down_eta || 0;
		m.down_eta = moment().add('s', m.down_eta).toDate().getTime();

		m.up_eta = m.up_eta || 0;
		m.up_eta = moment().add('s', m.up_eta).toDate().getTime();
		m.paused = app.pausedModel && app.pausedModel.get('value');
		if(!m.encryptedsecret && m.secrettype == 4)
			m.encryptedsecret = m.secret;

		if(m.keyrequest &&
				(m.keyrequest.status == SyncConstants.SYNC_REQUEST_EXPIRED ||
				 m.keyrequest.status == SyncConstants.SYNC_REQUEST_REJECTED)
			)
			m.keyrequest.invalid = true;

		// insert settings into store
		var shareOptions = app.store.get('shareOptions') || {};
		if (!shareOptions.hasOwnProperty(m.secret)) {
			var shareValues = {
				readwrite: false,
				expiration: 3,
				usages: 0,
				approvals: true
			};
			shareOptions[m.secret] = shareValues;
			m.shareOptions = shareValues;
			app.store.set('shareOptions', shareOptions);
		} else {
			m.shareOptions = shareOptions[m.secret];
		}
		return m;
	},
	setStatusType: function() {
		if(this.get('error'))
			this.set('statusType','error');

		else if(this.get('keyrequest') && this.get('keyrequest').status == SyncConstants.SYNC_REQUEST_REJECTED)
			this.set('statusType','requestDenied');

		else if(this.get('keyrequest') && this.get('keyrequest').status == SyncConstants.SYNC_REQUEST_PENDING)
			this.set('statusType','nokey');

		else if(this.get('keyrequest') && this.get('keyrequest').status == SyncConstants.SYNC_REQUEST_EXPIRED)
			this.set('statusType','requestExpired');

		else if(this.get('approval') && this.get('approval').length > 0)
			this.set('statusType', 'approval');

		else if(!this.get('devices').length)
			this.set('statusType','noPeers');

		else if(this.get('paused'))
			this.set('statusType','paused');

		else if(this.get('connectedDownDiff') && this.get('down_speed') > 0 && this.get('connectedUpDiff') && this.get('up_speed') > 0)
			this.set('statusType','downAndUp');

		else if(this.get('connectedDownDiff') && this.get('down_speed') > 0)
			this.set('statusType','downloading');

		else if(this.get('connectedUpDiff') && this.get('up_speed') > 0)
			this.set('statusType','uploading');

		else if(this.get('waitingToReceive'))
			this.setStatusOutOfSync();

		else if(this.get('waitingToSend') && this.get('syncedPeers') == 0)
			this.setStatusPeersOutOfSync();

		else
			this.set('statusType','synced');
	},
	setStatusOutOfSync: function() {
		if(this.outOfSyncTimeout) return;
		clearTimeout(this.peersOutOfSyncTimeout);
		delete this.peersOutOfSyncTimeout;
		this.outOfSyncTimeout = setTimeout(_.bind(function(){
			this.set('statusType','outOfSync');
		}, this), 15000);
	},
	setStatusPeersOutOfSync: function() {
		if(this.peersOutOfSyncTimeout) return;
		clearTimeout(this.outOfSyncTimeout);
		delete this.outOfSyncTimeout;
		this.peersOutOfSyncTimeout = setTimeout(_.bind(function(){
			this.set('statusType','peersOutOfSync');
		}, this), 15000);

	},
	clearOutOfSyncTimer: function() {
		clearTimeout(this.outOfSyncTimeout);
		delete this.outOfSyncTimeout;
		clearTimeout(this.peersOutOfSyncTimeout);
		delete this.peersOutOfSyncTimeout;
	},
	setNewSecret: function(s, opts) {
		var secret = this.get('secret');
		utWebUI.updateSecret(secret, s, {
			success: _.bind(function(data) {

				if(!data.rosecret || !data.secret) {
					opts && opts.error && opts.error.apply(this, arguments);
					return;
				}
				this.set('oldSecret', this.get('secret'));
				this.set({
					secret: data.secret,
					readonlysecret: data.rosecret
				});

				opts && opts.success.apply(this, arguments);
			}, this),
			error: opts.error
		});
	}
});


app.col.Folders  = Backbone.Collection.extend({
	initialize: function() {
		if (!app.isDesktop) {
			this.on('sync', this.updateSpeeds);
		}
		this.loading = true;
	},
	model: app.model.Folder,
	updateSpeeds: function() {
		$('#totalspeed .downSpeed').text(app.utils.formatSpeed(this.recv_speed));
		$('#totalspeed .upSpeed').text(app.utils.formatSpeed(this.send_speed));
	},
	sync: function(method, model, opts) {
		var _this = this;
		utWebUI.getSyncFolders(function(c) {
			var folders = c.folders;
			if(c.speed) {
				_this.recv_speed = c.speed.downspeed;
				_this.send_speed = c.speed.upspeed;
			}
			if(_this.loading && !c.loading) {
				app.ready = true;
				$(document).trigger('appReady');
			}
			_this.loading = c.loading;
			opts.success(folders);
		});
	}
});


app.view.Folder = app.view.Base.extend({
	template: 'folder',
	tagName: 'tr',
	className: 'folder',
	events: {
		// options menu stuff
		'click .optionsButton': 'openOptionsMenu',
		'click .peerlist-trigger': 'openPeerlist',
		'click .openarchive-trigger': 'openArchive',
		'click .properties-trigger': 'openPreferences',
		'click .delete-trigger,.disconnectButton': 'removeFolder',
		'click .copy-triggerRO': 'handleCopyRO',
		'click .copy-triggerRW': 'handleCopyRW',

		// share button
		'click .shareButton': 'openNewSharing',

		// pending secret modal
		'click .pendingSecret': 'openPendingModal',

		// approval required
		'click .approvalRequired': 'openApproval',

		// double click action
		'dblclick': 'openFolder',

		// close options menu on mouseleave
		'mouseleave': 'closeOptionsMenu'
	},
	initialize: function() {
		_.bindAll(this, 'openPreferences', 'initStatusTooltip', 'deleteShareOptions');
		app.view.Base.prototype.initialize.apply(this, arguments);

		this.listenTo(this.model, 'change:keyrequest', this.render);
		this.listenTo(this.model, 'change:name', this.renderName);
		this.listenTo(this.model, 'change:statusType change:error change:approvaltrigger', this.renderStatus);
		this.listenTo(this.model, 'change:locked_files', this.renderLockedFiles);
		this.listenTo(this.model, 'change:indexing', this.renderIndexing);
		this.listenTo(this.model, 'change:up_status change:down_status', this.renderProgress);

		this.listenTo(this.model, 'change:down_speed', this.renderDownSpeed);
		this.listenTo(this.model, 'change:up_speed', this.renderUpSpeed);
		this.listenTo(this.model, 'change:paused', this.renderPaused);
		this.listenTo(this.model, 'change:path', this.renderPath);
		this.listenTo(this.model, 'change:size', this.renderSize);
		this.listenTo(this.model, 'change:date_added', this.renderDateadded);
		this.listenTo(this.model, 'change:last_modified', this.renderLastmodified);
		this.listenTo(this.model, 'change:has_key change:numConnectedPeers change:numPeers', this.renderPeers);
		this.listenTo(this.model, 'change', this.initStatusTooltip);

		this.listenTo(this.model, 'remove', this.remove);
		this.listenTo(this.model, 'integrationTrigger', this.handleIntegrationFolder);
		this.listenTo(app.settingsModel, 'change:show_copy_key', this.render);
	},
	/********************
		RENDERING FUNCTIONS
	********************/
	preRender: function() {
		this.options.showCopy = app.settingsModel.get('show_copy_key') || false;
		this.options.columns = app.store.get('columns');
		switch(this.model.get('secrettype')) {
			case 1:
				this.options.secretType = 'read/write';
				break;
			case 2:
				this.options.secretType = 'readOnly';
				break;
		}

	},
	postRender: function() {
		// attach tooltip
		this.$('span[data-toggle=tooltip]').tooltip();
		if(this.model.get('paused'))
			this.$el.addClass('paused');
		else
			this.$el.removeClass('paused');

		if(_.contains(['downAndUp', 'downloading', 'uploading'], this.model.get('statusType')))
			this.setProgressBar();

		if(this.model.get('keyrequest') &&
			 this.model.get('keyrequest').invalid &&
			 !this.model.hasBeenHighlighted
			) {
			this.$el.addClass('requestDenied');
			var _this = this;
			setTimeout(function() {
				_this.$el.removeClass('requestDenied', 500);
				_this.model.hasBeenHighlighted = true;
			}, 5000);
		}

		this.dateUpdateInterval = setInterval(_.bind(function() {
			this.renderDateadded();
			this.renderLastmodified();
		}, this), 60000);

		// highlight row?
		if(this.model.id == this.model.collection.newFolderSecret) {
			this.model.collection.newFolderSecret = undefined;
			this.$el.addClass('highlight');
			var _this = this;
			setTimeout(function() {
				_this.$el.removeClass('highlight', 500);
			}, 5000);

			_.defer(function() {
				// scroll to row
				_this.$el.offsetParent().scrollTo(_this.$el, 800);
			});
		}

		if(this.model.collection.newFolderAdded && (!(app.store.get('firstRunTips') || {}).newFolder)) {
			this.model.collection.newFolderAdded = undefined;
			_.defer(_.bind(function() {
				this.$('.statusMessage').tooltip('destroy').firstRunTooltip({
					title: this.callTemplate('template-first-run-new-folder'),
					container: 'body'
				}, 'newFolder');
			}, this));
		}

		if(this.model.collection.newFolderLinked && (!(app.store.get('firstRunTips') || {}).newLink)) {
			this.model.collection.newFolderLinked = undefined;
			this.newLinkTooltipShown = true;
			_.defer(_.bind(function() {
				this.$('.statusMessage')
				.tooltip('destroy')
				.firstRunTooltip({
					title: this.callTemplate('template-first-run-new-link'),
					container: 'body'
				}, 'newLink')
				.on('hide.bs.tooltip', _.bind(function() {
					this.newLinkTooltipShown = undefined;
				}, this));
			}, this));
		}

		this.$('.lockedFilesStatus a').tooltip();

		if (app.browserInfo.os === "mac" && app.scrollbarWidth > 0) {
			this.$('.options-container').css('right', app.scrollbarWidth + 'px');
		}
	},
	renderStatus: function() {
		if (this.model.has('approval')) {
			this.options.count = (this.model.get('approval') || []).length || 0;
		}

		this.$('.statusMessage').html(this.callTemplate('partial-folder-status'));
		this.$('.statusColumn')
			.removeClass (function (index, css) {
				return (css.match (/(^|\s)statusType-\S+/g) || []).join(' ');
			})
			.addClass('statusType-' + this.model.get('statusType'));

		if(_.contains(['downAndUp', 'downloading', 'uploading'], this.model.get('statusType')))
			this.setProgressBar();
	},
	renderIndexing: function() {
		if(this.model.get('indexing'))
			return this.$('.statusColumn').append(this.callTemplate('partial-status-indexing'));

		this.$('.indexingStatus').remove();
	},
	renderLockedFiles: function() {
		if(this.model.get('locked_files')) {
			if(this.$('.lockedFilesStatus').length)
				return this.$('.lockedFilesStatus a').text(this.callTemplate('partial-status-locked-files-text'));

			this.$('.statusMessage').after(this.callTemplate('partial-status-locked-files'));
			this.$('.lockedFilesStatus a').tooltip();
			return;
		}

		this.$('.lockedFilesStatus a').tooltip('destroy');
		this.$('.lockedFilesStatus').remove();
	},
	renderPaused: function() {
		if(this.model.get('paused'))
			this.$el.addClass('paused');
		else
			this.$el.removeClass('paused');
	},
	renderName: function() {
		this.$('.nameLabel').text(this.model.get('name'));
	},
	renderDownSpeed: function() {
		this.$('.receivingSpeedColumn').html(this.callTemplate('partial-folder-receiving-speed'));
	},
	renderUpSpeed: function() {
		this.$('.sendingSpeedColumn').html(this.callTemplate('partial-folder-sending-speed'));
	},
	renderProgress: function() {
		this.renderStatus();
		this.$('.progressColumn').html(this.callTemplate('partial-folder-progress'));
	},
	renderPath: function() {
		this.$('.pathColumn').text(this.model.get('path'));
		// rerender tooltip
		this.$('.nameColumn > span')
			.tooltip('destroy')
			.attr('title', this.callTemplate('partial-folder-path-tooltip'))
			.tooltip();
	},
	renderSize: function() {
		if(!this.model.get('has_key')) return;
		this.$('.sizeColumn').text(
			this.model.get('has_key') ?
				app.utils.formatFileSize(this.model.get('size')) :
				''
		);
	},
	renderDateadded: function() {
		this.$('.dateAddedColumn').html(this.callTemplate('partial-folder-dateadded'));
	},
	renderLastmodified: function() {
		this.$('.lastModifiedColumn').html(this.callTemplate('partial-folder-lastmodified'));
	},
	renderPeers: function() {
		this.$('.peersColumn').html(this.callTemplate('partial-folder-peers'));
	},
	initStatusTooltip: function() {
		var oldTooltipText = this.tooltipText;
		this.tooltipText = undefined;

		switch(this.model.get('statusType')) {
			case 'downloading':
				this.tooltipText = this.callTemplate('template-status-tooltip-downloading');
				break;
			case 'uploading':
				this.tooltipText = this.callTemplate('template-status-tooltip-uploading');
				break;
			case 'downAndUp':
				this.tooltipText = this.callTemplate('template-status-tooltip-downAndUp');
				break;
			case 'noPeers':
				this.tooltipText = this.callTemplate('template-status-tooltip-noPeers');
				break;
			case 'peersOutOfSync':
				this.tooltipText = this.callTemplate('template-status-tooltip-peersOutOfSync', {
					amount: app.utils.formatFileSize(this.model.get('updiff'))
				});
				break;
			case 'outOfSync':
				var peer = this.model.get('devices').filter(function(m) {
					return m.get('downdiff') > 0;
				});
				if(peer.length > 1)
					this.tooltipText = this.callTemplate('template-status-tooltip-outOfSync-multiple');
				else if(peer.length == 1)
					this.tooltipText = this.callTemplate('template-status-tooltip-outOfSync', {
						peer: peer[0].get('name'),
						amount: app.utils.formatFileSize(this.model.get('downdiff'))
					});

				// check send status too
				if(this.model.get('waitingToSend')) {
					this.tooltipText = this.tooltipText + '<br/><br/>' +
						this.callTemplate('template-status-tooltip-peersOutOfSync', {
							amount: app.utils.formatFileSize(this.model.get('updiff'))
						});
				}
				break;

			case 'requestExpired':
				this.tooltipText = this.callTemplate('template-status-tooltip-expired');
				break;

			case 'synced':
				if(this.model.get('lastSentTime') > this.model.get('lastReceivedTime') && this.model.get('lastSentTime') > 0)
					this.tooltipText = this.callTemplate('template-status-tooltip-lastSent');
				else if(this.model.get('lastReceivedTime') > 0)
					this.tooltipText = this.callTemplate('template-status-tooltip-lastReceived');
				break;

			case 'nokey':
				this.tooltipText = this.callTemplate('template-status-tooltip-nokey');
				break;
		}

		if(this.newLinkTooltipShown && _.contains(['downloading', 'uploading', 'downAndUp'], this.model.get('statusType')))
			this.tooltipText = this.callTemplate('template-first-run-new-link-transferring');

		if(this.newLinkTooltipShown && this.model.get('statusType') == 'nokey')
			this.tooltipText = this.callTemplate('template-first-run-new-link');

		if(oldTooltipText == this.tooltipText) return;

		if(!this.tooltipText) {
			this.$('.statusMessage').tooltip('destroy');
			return;
		}

		var tip = this.$('.statusMessage').data('bs.tooltip');
		if(tip) {
			tip.tip().find('.tooltip-inner').html(this.tooltipText);
			tip.options.title = this.tooltipText;
			tip.fixPlacement();
			return;
		}

		this.$('.statusMessage').tooltip({
			html: true,
			title: this.tooltipText,
			delay: 500,
			container: 'body',
			animation: false
		});
	},
	handleIntegrationFolder: function() {
		if((!(app.store.get('firstRunTips') || {}).integrationFolder)) {
			var _this = this;
			var optionsStuff = _this.$('.options .optionsButton, .options .shareButton, .options .divider').addClass('show');
			app.foldersView.showRightmost(function() {
				_this.$('.shareButton').tooltip('destroy').firstRunTooltip({
					title: _this.callTemplate('template-first-run-integration-folder'),
					container: 'body',
					viewport: '.resizableTableContainer'
				}, 'integrationFolder', function() {
					optionsStuff.removeClass('show');
				});
			});
		}
	},
	setProgressBar: function() {
		var ratio;
		var uploading = false;
		if(this.model.get('statusType') == 'uploading') {
			ratio = this.model.get('up_status')/100;
			uploading = true;
		}
		else
			ratio = this.model.get('down_status')/100;
		var circle = new app.view.ProgressBar({
			ratio: ratio,
			color: uploading ? '#7ABD3E' : '#0080FF'
		});
		this.$('.statusMessage').prepend(circle.render().el);
	},
	handleCopyRO: function() {
		if(!app.isDesktop) {
			var copyDialog = new app.view.CopyDialog({
				model: this.model,
				text: this.model.get('readonlysecret')
			});
			copyDialog.insert().open();
			return;
		}
		var secret = this.model.get('readonlysecret');
		btsync.copytoclipboard({text: secret});
		app.notify(
			$.t('secretCopyNotification'),
			'"' + this.model.get('name') + '" - ' + $.t('readonly')
		);
	},
	handleCopyRW: function() {
		if(!app.isDesktop) {
			var copyDialog = new app.view.CopyDialog({
				model: this.model,
				text: this.model.get('secret')
			});
			copyDialog.insert().open();
			return;
		}
		var secret = this.model.get('secret');
		btsync.copytoclipboard({text: secret});
		app.notify(
			$.t('secretCopyNotification'),
			'"' + this.model.get('name') + '" - ' + $.t('readWrite')
		);
	},
	/********************
		OPEN DIALOG WINDOWS
	********************/
	openPendingModal: function() {
		var modal = new app.view.PendingModal({model: this.model});
		modal.insert().open();
	},
	openApproval: function() {
		if (this.model.get('approval').length > 1) {
			var modal = new app.view.MultiApprovalDialog({
				collection: app.approvals,
				secretfilter: this.model.get('secret')
			});
			modal.insert().openScroll();
		} else if (this.model.get('approval').length === 1) {
			var approvalDialog = new app.view.ApprovalDialog({
				model: this.model.get('approval')[0]
			});
			approvalDialog.insert().open();
		}
		return false;
	},
	openPreferences: function() {
		var folderPrefDialog = new app.view.FolderPreferences({
			model: this.model
		});
		folderPrefDialog.insert().openScroll();
		return false;
	},
	openNewSharing: function() {
		var d = new app.view.EmptyDialog({model:this.model});
		d.insert().openScroll();
	},
	openPeerlist: function() {
		var dialog = new app.view.PeerListDialog({
			model: this.model
		});
		dialog.insert().openScroll();
		return false;
	},
	openArchive: function() {
		btsync.openpath({
			path: this.model.get('archive')
		});
		this.$el.trigger('mouseout');
	},
	removeFolder: function() {
		var _this = this;
		btconfirm({
			message: $.t('removeFolderMessage'),
			title: $.t('disconnect'),
			folder: this.model,
			callback: function(success) {
				if (success) {
					utWebUI.removeSyncFolder(_this.model.get('secret'), function() {
						_this.deleteShareOptions();
						getFolders();
					});
				}
			}
		});
		return false;
	},
	deleteShareOptions: function() {
		var allShareOptions = app.store.get('shareOptions');
		delete allShareOptions[this.model.get('secret')];
		app.store.set('shareOptions', allShareOptions);
	},
	openOptionsMenu: function() {
		var tableContainer = $('#folderContainer');
		var tableBottomOffset = tableContainer.offset().top + tableContainer.outerHeight()
		if (tableBottomOffset - this.$el.offset().top < 200) {
			this.$('.dropdown-menu').addClass('dropdown-menu-up');
		} else {
			this.$('.dropdown-menu').removeClass('dropdown-menu-up');
		}

		if (this.$('.optionsButton').hasClass('open')) return;
		this.$('[data-toggle=dropdown]').dropdown('toggle');
		return false;
	},
	/****************
		OTHER FUNCTIONS
	****************/
	closeOptionsMenu: function() {
		if(!this.$('.optionsButton').hasClass('open')) return;
		this.$('[data-toggle=dropdown]').dropdown('toggle');
	},
	openFolder: function() {
		if(!app.isDesktop) return;
		btsync.openpath({
			path: this.model.get('path')
		});
		return false;
	},
	remove: function() {
		clearInterval(this.dateUpdateInterval);
		this.$('[data-original-title]').tooltip('destroy');
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});


app.view.ResizableTable = app.view.Base.extend({
	className: 'resizableTableContainer',
	initialize: function() {
		_.bindAll(this, 'windowResize', 'adjustPaddingColumn');
		app.view.Base.prototype.initialize.apply(this, arguments);
	},
	postRender: function() {
		this.$el.resizableColumns();
		if(this.$('.paddingColumn').length) {
			// init padding column
			this.throttledResize = _.throttle(this.windowResize, 500);
			$(window).on('resize', this.throttledResize);

			var _this = this;
			this.$el.on('resizablecolumnsresize', function(e, opts) {
				// adjust padding column
				_this.adjustPaddingColumn();
			});
		}
	},
	deferred_post_render: function() {
		this.adjustPaddingColumn();
	},
	windowResize: function(e) {
		// why can't I stop propagation of the resizable 'resize' events?!
		if(e.target != window) return;

		this.adjustPaddingColumn();
	},
	adjustPaddingColumn: function(e) {
		var totalWidth = 0;
		this.$('.col-sizer').each(function(index, element) {
			totalWidth += parseInt($(element).css('width'));
		});

		var containerWidth = this.$el.outerWidth();

		if (totalWidth < containerWidth) {
			var paddingWidth = containerWidth - totalWidth;
			if (app.browserInfo.os === "win") {
				paddingWidth = paddingWidth - app.scrollbarWidth;
			}
			this.$('col:nth-child(' + (this.$('.paddingColumn').index() + 1) + ')').width(paddingWidth);
		}
		return false;
	},
	remove: function() {
		$(window).off('resize', this.windowResize);
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});


app.view.FolderTable = app.view.ResizableTable.extend({
	template: 'folder-table',
	initialize: function() {
		_.bindAll(this, 'addFolder');
		app.view.ResizableTable.prototype.initialize.apply(this, arguments);
		this.listenTo(app.folders, 'add', this.addFolder);
		// set default columns
		app.store.set('columns', app.store.get('columns') || {
			name: true,
			status: true
		});
	},
	preRender: function() {
		this.options.columns = app.store.get('columns');
	},
	postRender: function() {
		app.view.ResizableTable.prototype.postRender.apply(this, arguments);
		this.renderFolders();
	},
	renderFolders: function() {
		if(!(app.folders && app.folders.length)) return;

		app.folders.each(this.addFolder);
	},
	addFolder: function(m) {
		this.$('tbody').append(new app.view.Folder({model:m}).render().el);
	}
});


app.view.Folders = app.view.Base.extend({
	template: 'folders',
	className: 'foldersTableContainer empty',
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.listenTo(app.folders, 'sync', this.checkCount);
		this.isEmpty = true;
		this.contextMenu = new app.view.FolderContextMenu;
		$(window).on('columnsChanged', this.render);
	},
	postRender: function() {
		this.$el.append(new app.view.FolderTable().render().el);
		this.$el.append(this.contextMenu.render().el);
		this.checkCount();
	},
	checkCount: function() {
		var isFirstRun = !app.store.get('foldersAdded');

		if(app.folders.length && this.isEmpty) {
			this.isEmpty = false;
			return this.$el.removeClass('empty');
		}
		if(!app.folders.length) {
			if(app.folders.loading)
				this.$('.emptyMessage').text($.t('loading') + $.t('ellipse'));
			else if(isFirstRun) {
				this.$('.emptyMessage').text($.t('welcome'));
				if(app.config.linkOnboarding)
					this.$('.emptyMessage').append('<h3>' + $.t('linkOnboardingMessage') + '</h3>');
			}
			else
				this.$('.emptyMessage').text($.t('noFolders'));

			if(!this.isEmpty) {
				this.isEmpty = true;
				this.$el.addClass('empty');
			}
		}
	},
	showRightmost: function(cb) {
		this.$el.find('.resizableTableContainer').animate({
			scrollLeft : this.$el.find('#filetable').outerWidth()
		}, 700, function() {
			cb && cb();
		});
	}
});

app.view.FolderContextMenu = app.view.Base.extend({
	template: 'folderContextMenu',
	id:'folder-context-menu',
	events: {
		'click a': 'itemSelected'
	},
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
		$(window).on('columnsChanged', this.render);
	},
	preRender: function() {
		this.options.columns = app.store.get('columns') || {};
	},
	postRender: function() {
		this.delegateEvents();
	},
	itemSelected: function(e) {
		var column = $(e.currentTarget).attr('data-value');
		this.options.columns[column] = !this.options.columns[column];
		app.store.set('columns', this.options.columns);
		$(window).trigger('columnsChanged');
	}
});

