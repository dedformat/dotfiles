app.view.ConfirmDialog = app.view.BaseDialog.extend({
	template: 'confirm-dialog',
	id: 'confirm-dialog',
	events: {
		'click #cancelButton': 'cancelClicked',
		'click #okButton': 'okClicked',
		'hidden.bs.modal': 'remove'
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		this.options.isConfirm = !!this.options.callback;
		if(this.options.folder) {
			this.options.folder = this.options.folder.toJSON();
			this.options.folder.pageTitle = this.options.title;
		}
	},
	cancelClicked: function() {
		this.options.callback && this.options.callback(false);
		this.close();
	},
	okClicked: function() {
		this.options.callback && this.options.callback(true);
		this.close();
	},
	open: function() {
		this.$el.modal({
			backdrop: 'static',
			keyboard: false
		});
	}
});