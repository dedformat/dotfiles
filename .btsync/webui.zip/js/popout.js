app.view.Popout = app.view.BaseDialog.extend({
    template: 'popout',
    className: 'popout-parent hidden',
    events: {
        // 'hidden.bs.modal': 'remove',
        // 'click #downloadDebugLogLink': 'downloadDebugLinkClicked',
    },
    initialize: function(options) {
        // if (!options || !options.dockElement) {
        //     console.error('dockElement must be specified.');
        // }

        _.bindAll(this, 'handleClick');
        app.view.BaseDialog.prototype.initialize.apply(this, arguments);

        var defaultValues = {
            "direction" : "bottom",
            "position" : 2,
            "dockElementPadding": 7,
            "windowPadding" : 15,
            "width": 400,
            "minheight" : 100,
            "arrow": true
        };

        this.options = _.extend(
            defaultValues,
            this.options || {}
        );

        this._views = [];
        this._tailindex = -1;
        this._allRendered = false;
    },
    deferred_post_render: function() {
        this.calculatePosition();
        this.$el.addClass(this.options.direction);
        if (this.options.arrow) {
            this.$el.append('<div class="arrow-tip"></div>');
        }
    },
    setDockElement: function(dockElement) {
        // TODO: validate
        this.dockElement = dockElement;
        this.calculatePosition();
    },
    calculatePosition: function() {
        if (!this.dockElement) return;

        var positionOptions = {};

        switch(this.options.direction) {
            case "top":
                if (!this._verticalset) {
                    this._verticalset = ($(window).outerHeight() - (this.dockElement.offset().top - this.options.dockElementPadding));
                    positionOptions['bottom'] = this._verticalset + 'px';
                }

                if (this.options.position == 1) {
                    positionOptions['right'] = ($(window).outerWidth() - (this.dockElement.offset().left + this.dockElement.outerWidth())) + 'px';
                } else if (this.options.position == 3) {
                    positionOptions['left'] = (this.dockElement.offset().left) + 'px';
                } else {
                    var leftval = (this.dockElement.offset().left + (this.dockElement.outerWidth()/2) - (this.options.width / 2));
                    
                    if (leftval + this.options.width > $(window).outerWidth()) {
                        leftval = $(window).outerWidth() - this.options.windowPadding - this.options.width; 
                    }

                    positionOptions['left'] = leftval + 'px';
                }
                break;
            case "bottom":
            default:
                if (!this._verticalset) {
                    this._verticalset = (this.dockElement.offset().top + this.dockElement.outerHeight() + this.options.dockElementPadding)
                    positionOptions['top'] = this._verticalset + 'px';
                }

                if (this.options.position === 1) {
                    console.log('hit');
                    positionOptions['right'] = ($(window).outerWidth() - (this.dockElement.offset().left + this.dockElement.outerWidth())) + 'px';
                } else if (this.options.position === 3) {
                    positionOptions['left'] = (this.dockElement.offset().left) + 'px';
                } else {
                    var leftval = (this.dockElement.offset().left + (this.dockElement.outerWidth()/2) - (this.options.width / 2));
                    
                    if (leftval + this.options.width > $(window).outerWidth()) {
                        leftval = $(window).outerWidth() - this.options.windowPadding - this.options.width; 
                    }

                    positionOptions['left'] = leftval + 'px';
                }
            break;
        }

        this.$el.css(positionOptions);
   
        // Max-height
        this.$('.popout-container').css('max-height', ($(window).outerHeight()  - this._verticalset - this.options.windowPadding) + 'px');

        if (this.options.arrow) {
            this.setArrowPosition(this.options.position, positionOptions);
        }
    },
    setArrowPosition: function(position, positionOptions) {
        var arrowOptions = {};
        if (position === 1) {
            arrowOptions['left'] = (this.options.width - (this.dockElement.outerWidth() / 2)) + 'px';
        } else if (position === 3) {
            arrowOptions['left'] = this.dockElement.outerWidth() / 2 + 'px';
        } else {
            if (positionOptions.left) {
                arrowOptions['left'] = - (parseInt(positionOptions.left) - (this.dockElement.offset().left + (this.dockElement.outerWidth() / 2))) + 'px';
            } else if (positionOptions.right) {
                // TODO:
            }
        }
        this.$('.arrow-tip').css(arrowOptions);
    },
    positionArrow: function() {
        var arrowLeft = (this.dockElement.offset().left + (this.dockElement.outerHeight() / 2)) + 'px';
        this.$('.arrow-tip').css('left', arrowLeft);
    },
    insert: function() {
        $('body').append(this.render().el);
        return this;
    },
    toggle: function() {
        if (this.visible) {
            this.hide();
        } else {
            this.show();
        }
    },
    handleClick: function() {
        this.hide();
    },
    show: function() {
        this.calculatePosition();
        this.$el.removeClass('hidden');
        this.visible = true;
        this.dockElement.addClass('active');
        $(window).on("resize", this.handleResize);
        $(window).on('click', this.handleClick);
    },
    hide: function() {
        this.$el.addClass('hidden');
        this.visible = false;
        this.dockElement.removeClass('active');
        $(window).off("resize", this.handleResize);
        $(window).off('click', this.handleClick);
    },
    handleResize: function() {
        console.log('resizing');
        this.calculatePosition();
    },
    remove: function() {
        // this.$el.find('.tableScrollContainer').unbind('scroll', this.scroll);

        // while(this._views.length) {
        //     this._views.pop().remove();
        // }

        app.view.BaseDialog.prototype.remove.apply(this, arguments);
    }
});
